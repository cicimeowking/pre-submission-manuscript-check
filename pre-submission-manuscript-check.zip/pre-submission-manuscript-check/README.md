# Pre-submission Manuscript Check

**An AI-assisted, journal-independent workflow for checking manuscripts before submission.**

Pre-submission Manuscript Check helps authors identify common internal inconsistencies and reporting issues before submitting a research manuscript. It combines a general check for all manuscripts with an additional, conditional workflow for medical and life-science research.

The tool is designed to help authors **find issues worth reviewing**—not to judge the scientific merit of a study, enforce a particular journal's formatting rules, or replace editorial assessment or peer review.

> **Current version:** v2.2  
> **Current report language:** Chinese  
> **Core principle:** classify first, check only what applies, and report verifiable differences rather than inventing explanations.

---

## Why use this tool?

Journal requirements differ. A manuscript can be internally inconsistent even when its formatting is correct, and a requirement that applies to a clinical trial may be irrelevant to a paper about materials, ecology, engineering, or economics.

This workflow addresses that distinction:

- **Journal-independent:** it does not assume a journal's section structure, reference style, word limits, figure specifications, or layout.
- **Two-track workflow:** every manuscript receives the general check; medical and life-science manuscripts receive additional checks when applicable.
- **Evidence-oriented:** findings should identify the locations and wording being compared. The tool must not fabricate quotations, page or line numbers, DOIs, registration numbers, approval numbers, or verification results.
- **Human review remains essential:** automated and AI-assisted findings are prompts for author verification, not definitive editorial or scientific judgments.

## What does it check?

### 1. General workflow — for all manuscripts

| Area | What is checked |
|---|---|
| Authors and affiliations | Full author names; consistency between the author list and Author Contributions; corresponding-author markers; affiliation numbering; relevant authorship inconsistencies |
| Internal consistency | Sample sizes, group totals, percentages, statistical values, terminology, study-design descriptions, versions, and statements repeated across the abstract, main text, tables, figures, and discussion |
| Declarations | Author contributions, conflicts of interest, funding, data availability, and generative-AI-use disclosure |
| Figures and tables | Numbering, in-text callouts, captions and notes, panel labels, group counts, abbreviations, units, and consistency with the main text |
| References and citations | Whether in-text citations and reference-list entries correspond; numbering or author–year matching; missing, duplicated, or apparently uncited entries |
| Writing conventions | Potential inconsistencies in italics, biological names, gene/protein notation, statistical symbols, chemical notation, superscripts/subscripts, minus signs, multiplication signs, and micro symbols |

### 2. Additional medical and life-science workflow — when applicable

The manuscript is first classified. If it falls into the medical/life-science category, the general workflow is supplemented by checks selected according to the study type and content.

| Area | What is checked |
|---|---|
| Ethics and consent | Ethics committee information, approval identifiers and dates, informed consent, consent for publication, and relevant exemption statements |
| Registration timeline | Potential inconsistencies between trial registration, ethics approval, first participant enrollment, and review registration/search dates |
| Clinical-data consistency | Participant flow, analysis populations, follow-up periods, doses and treatment duration, outcomes, effect estimates, confidence intervals, and subgroup reporting |
| Reporting-guideline items | Selected high-frequency reporting items relevant to the identifiable study design (for example, CONSORT, STROBE, PRISMA, ARRIVE, CARE, or SPIRIT) |
| Biological materials and data | Animal welfare information, cell-line source and authentication, human sample information, public data accession numbers, and relevant third-party resources |

**Important:** a medical/biological subject does not mean that every medical check applies. Each item must be assessed for applicability. If the study type cannot be determined reliably, the classification should be marked as provisional rather than presented as confirmed.

## How the workflow operates

```text
                    Manuscript supplied
                            |
                            v
                  Step 0: Classify manuscript
                     /                 \
                    v                   v
             Medical / life       Non-medical
               sciences              research
                    |                   |
                    v                   |
             General checks <-----------+
                    |
                    v
          Medical-specific checks
             (if applicable)
                    |
                    v
       Figures, tables and references
                    |
                    v
       Citation appropriateness review
                    |
                    v
          Generate two reports
             /             \
            v               v
      Word self-check   Excel citation
          report       assessment sheet
```

### Step-by-step

1. **Classify the manuscript.** Determine whether it belongs to the medical/life-science track or the non-medical track. The classification is based on the research subject, medical elements, and direction of the conclusions.
2. **Extract manuscript content.** Use the document-extraction script to collect text, headings, tables, author information, declaration clues, dates, and figure information.
3. **Run the general checks.** Review authorship, internal consistency, general declarations, figure/table callouts, reference matching, and typography.
4. **Run the additional checks when applicable.** For medical/life-science manuscripts, examine ethics and consent, registration timelines, clinical-data consistency, reporting-guideline items, and biological-material declarations as relevant.
5. **Review citation appropriateness.** Extract citations and match them to reference-list entries. Assess whether the cited work appears appropriate for the claim, using only the available source information and clearly stating when that information is insufficient.
6. **Generate the reports.** Produce a manuscript self-check report in Word and a citation-appropriateness assessment in Excel.

## Output files

A complete run is designed to produce **two complementary reports**:

### 1. Manuscript self-check report (`.docx`)

The report is designed to include:

- Manuscript classification and the workflow applied
- Summary of check results and issue levels
- Author-list and contribution comparison
- Declaration coverage matrix
- Internal-consistency comparison table
- Typography findings
- Summary of issues and suggested author actions
- Citation-related findings and stated limitations

### 2. Citation-appropriateness report (`.xlsx`)

The spreadsheet is designed to record citation-level findings, including the reference identifier, citation location or section, assessment, and rationale. It is intended to help authors review whether cited references are relevant to the statements they support.

The exact contents depend on the manuscript, citation system, available reference information, and successful execution of the relevant scripts.

> **Current limitation:** the Word self-check report is specified in Chinese in this version. An English report option would be a useful future enhancement for international users.

## What this tool deliberately does not do

This is a content-oriented pre-submission check, not a journal-formatting service.

It does **not** automatically check or enforce:

- Journal-specific section names, section order, or section numbering
- Abstract structure, abstract word limits, or keyword limits
- Reference styles such as Vancouver, APA, or Harvard
- Journal-specific in-text citation formatting
- Figure resolution, image format, dimensions, or color mode
- Table layout, fonts, font sizes, line spacing, margins, or page layout
- Line numbering, file naming, or supplementary-file naming conventions
- Language quality, novelty, scientific validity, study-design quality, or whether a statistical method is scientifically appropriate
- The real-world identity, affiliation, or authorship eligibility of any author

If an author wants to check a particular journal's requirements, they should provide that journal's current *Instructions for Authors* or *Author Guidelines*. Those requirements can then be treated as additional, user-provided parameters. The tool should not guess the target journal or silently apply a journal template.

## Repository structure

The skill specification refers to the following project resources. A complete, runnable public repository should include the relevant files and preserve their relative paths.

```text
.
├── README.md
├── SKILL.md
├── scripts/
│   ├── qc_extract.py
│   ├── qc_report_gen.py
│   ├── extract_citations.py
│   ├── extract_citations_ay.py
│   ├── build_judgment_excel.py
│   ├── build_excel.py
│   ├── desensitize_check.py
│   └── qc_typography.py
├── references/
│   ├── consistency-guidelines.md
│   ├── ethics-guidelines.md
│   └── reporting-guidelines.md
└── guidelines/
    └── [reporting-guideline resources]
```

The list above reflects the paths referenced by the skill specification. **A file being listed here does not mean it is already included in the repository.** Before publishing, make sure every referenced script and resource is present, its license permits redistribution, and the paths match the instructions in `SKILL.md`.

## Installation and use

This repository contains an AI-skill specification and a set of supporting scripts. The exact installation process depends on the AI assistant or agent environment in which the skill is used.

### 1. Get the repository

```bash
git clone <repository-url>
cd <repository-directory>
```

### 2. Check the project files

Before running the workflow, confirm that the `scripts/`, `references/`, and `guidelines/` resources referenced in `SKILL.md` are present.

### 3. Prepare the environment

Use the Python version and dependencies declared by the project. Install them using the repository's dependency file, if provided.

For example, if the repository includes a `requirements.txt`:

```bash
python -m pip install -r requirements.txt
```

Do not assume that this command is sufficient if dependencies are not documented. The repository maintainer should provide and test a dependency list before describing the project as ready to run.

### 4. Provide a manuscript to the compatible AI workflow

Use the skill in an AI assistant or agent environment that supports the repository's skill format and file access. Provide the manuscript file and request a pre-submission check.

The skill specification describes Word (`.docx`) as the input for its extraction and typography scripts. Support for PDF or other formats should not be assumed unless it is implemented and tested.

### 5. Review the findings

Read both reports carefully. Confirm every flagged issue against the original manuscript and make the final decisions yourself. A flagged item may be a false positive; an item that is not flagged is not guaranteed to be correct.

### Script entry points

The skill specification documents these example commands:

```bash
python scripts/qc_extract.py <manuscript.docx> <output.txt>

python scripts/qc_typography.py <manuscript.docx> [output.json]

python scripts/qc_report_gen.py --config <config.json>
```

Citation extraction and Excel generation are also part of the workflow. Refer to the relevant script's help output or documentation for its exact arguments. Do not treat the example commands as a complete end-to-end command until the scripts, dependencies, and configuration files have been tested together.

## Privacy and responsible use

Manuscripts may contain unpublished research, confidential information, personal data, or sensitive participant information. Please take care before submitting a manuscript to any AI service or third-party environment.

- The supporting Python scripts are designed for local file processing; do not interpret this as a guarantee that an AI assistant or agent processes uploaded content locally.
- When using an AI assistant, review that service's data controls, retention policy, and institutional requirements before providing unpublished or confidential material.
- Do not include patient names, contact details, identification numbers, or other directly identifying information in prompts or reports.
- The report should not reproduce email addresses, phone numbers, ORCID iDs, postal addresses, or identifiable patient details.
- The workflow does not verify author identities or affiliations. It checks consistency within the manuscript.
- Optional de-identification checks should be used only when needed and should not be treated as a substitute for removing sensitive information before sharing a file.

Authors are responsible for ensuring that their use of the tool complies with applicable research ethics requirements, institutional policies, confidentiality obligations, and the terms of any AI service they use.

## Interpretation of findings

Findings should distinguish between clear inconsistencies, potential issues, and suggestions for improvement. In particular:

- A difference between two locations should be reported with both locations and the observed values.
- The tool should not silently decide which conflicting value is correct.
- A missing statement should be described as “not identified in the manuscript examined,” not as proof that the underlying approval, consent, or activity does not exist.
- A possible registration-timeline issue should be presented with the dates and the applicable study-design context.
- Typography and biological-name checks may rely on dictionaries, patterns, or contextual inference; author verification is required.
- Citation relevance cannot be established reliably from a title alone. If only titles or abstracts are available, the report should say so.

## Limitations

This tool is intended as an aid, not a guarantee of submission readiness.

1. **Classification can be uncertain.** Interdisciplinary manuscripts may require author confirmation.
2. **Automated extraction can miss content.** Complex Word layouts, text boxes, embedded objects, equations, and unusual formatting may not be fully captured.
3. **Consistency checks need comparable information.** A value mentioned only once cannot be cross-checked against another location.
4. **Typography checks are imperfect.** Biological-name dictionaries and context rules may miss uncommon names or confuse gene and protein symbols. Document styles may also affect how italics are detected.
5. **Reporting-guideline checks are selective.** The workflow checks selected high-frequency items; it is not a complete certification of compliance with every reporting guideline.
6. **Citation assessments have evidence limits.** Matching a citation to a reference does not prove that the reference supports the claim. Full-text access and subject expertise may be needed.
7. **No external identity verification is performed.** The tool does not establish whether authors, affiliations, approvals, or contributions are genuine.
8. **No scientific peer review is performed.** The tool does not assess novelty, validity, causal inference, or the overall quality of the research.

Always inspect the original manuscript and verify important findings before submission.

## Contributing

Suggestions, issue reports, and contributions are welcome.

When reporting a problem, please include:

- The relevant script or workflow step
- A minimal example that does not disclose confidential or unpublished research
- The expected result and the actual result
- The software environment, where relevant

Please do not upload unpublished manuscripts, patient information, or other confidential material in public issue reports.

## Disclaimer

This project is provided for informational and educational purposes. It does not guarantee that a manuscript will meet the requirements of any journal, pass editorial screening, or be accepted for publication. Authors retain full responsibility for the accuracy, completeness, ethics, and final presentation of their manuscripts.

---

**Version:** v2.2  
**Skill specification:** `SKILL.md`
