# 内部一致性核查指南（Internal Consistency Check）— v7

> **定位**：投稿前自查的核心价值所在。稿件内容已基本定稿，**专业判断不是本工具重点**；
> 作者要挡的是「前后对不上」的低级错误——这类错误会直接印在上线版本里。
> **原则**：只查"同一个事实在不同位置说法是否一致"，**不评价研究设计优劣、不质疑结论是否成立**。

---

## 一、核对矩阵（逐项过，命中即记录）

输出到报告的 `ConsistencyTable`，四列：**核对项 | 位置 A | 位置 B | 结论**（结论取值：`一致` / `不一致` / `需核实`）

### 1. 数字类（最高频、最致命）

| # | 核对项 | 位置 A | 位置 B | 常见错误 |
|---|---|---|---|---|
| 1 | 样本量 n | Abstract | Methods / Results | 摘要 n=120，结果 n=118（脱落未说明） |
| 2 | 分组人数 | Results 正文 | 表格首行 / 流程图 | 各组相加 ≠ 总数 |
| 3 | 百分比 | 正文 | 同段表格 | 分子分母与百分比算不符（20/118 写成 18.6%） |
| 4 | 均值 ± SD | Abstract | Results 表 | 同一指标数值不同（12.4±2.1 vs 12.6±2.3） |
| 5 | P 值 | Results | Abstract / Discussion | 结果 P=0.032，讨论写 P=0.023；或把 P=0.048 写成 P<0.001 |
| 6 | 检验统计量 | 文中 | 表注 | t 值/χ²/F 值与自由度、P 值三者互相矛盾 |
| 7 | 95% CI | 正文 | 表格 | CI 区间跨 1（OR）却称"显著"；CI 上下限颠倒 |
| 8 | 效应量 | Abstract | Results | OR 1.85 vs 1.58 |
| 9 | 单位 | Abstract / Methods | Results / 表格 | mm vs cm；mg/kg vs mg/kg/d（见 SKILL 单位速查） |
| 10 | 时间跨度 | Methods | Results / 流程图 | 招募期 2019–2022，结果却写随访至 2025（无说明） |
| 11 | 随访时长 | Abstract | Results | 12 个月 vs 24 个月 |
| 12 | 剂量 / 疗程 | Methods | Results / 讨论 | 给药 10 mg/kg 写成 100 mg/kg |
| 13 | 金额 / 成本 | Results | Discussion | 数字与币种不一致 |
| 14 | 文献条数 | 正文提及 | References 列表 | "42 studies were included" 但列表 38 条 |
| 15 | 图表数量 | 正文引用 | 实际图表 | 引用了 Fig. 5 但全文只有 4 张图 |

### 1b. 时间线检查 ★（独立子组，四项必查）

> 这是投稿前自查的**合规红线**，不属于普通数字核对——它决定稿件是否踩了 ICMJE / COPE 的注册规范。
> 判定细则（四步法、各类型严格度、狡猾写法）见 `ethics-guidelines.md` §3.4.1。

| # | 核对项 | 位置 A | 位置 B | 红线条件 |
|---|---|---|---|---|
| T1 | **注册日期 vs 首例入组** ★ | 注册日期 D1（标题页/摘要末） | 招募期起点 D2（Methods） | **D1 > D2 = 回溯注册** → 标红 `高` |
| T2 | 注册日期 vs 伦理批准 | D1 | approval date D3 | D1 < D3 → `需核实` |
| T3 | 伦理批准 vs 首例入组 | D3 | D2 | D3 > D2 → `需核实`（可能先做后批） |
| T4 | PROSPERO 注册 vs 检索开始 | PROSPERO 注册日期 | Methods 检索日期 | 注册晚于检索开始 → `不一致` |

**输出要求**：
- 无论是否触发红线，**T1 必须出现在报告的 Internal Consistency Check 表中**（未触发写 `一致`；无注册日期写"未见注册日期"）
- T1 触发红线时：`checkItems` 加一行归入「伦理与声明」，状态 `FAIL`，优先级 `高`（Issue Summary 自动标红）
- 对话输出的汇总里该行前置 `🔴`


### 2. 标签与命名类

| # | 核对项 | 要点 |
|---|---|---|
| 16 | 分组名称 | 正文 "high-dose group" vs 表格 "Group A" vs 图注 "HD group" —— 若无对应说明即标 `需核实` |
| 17 | 组数 | 正文说 3 组，图表出现 4 组 / 反之 |
| 18 | 缩写 | 首次出现给全称，后文统一；AbA / ABA、Y1H / Y2H 类混用 |
| 19 | 基因 / 蛋白命名 | 斜体基因名 vs 正体蛋白名是否混用（同一名称两种写法） |
| 20 | 药物名称 | 商品名 / 通用名混用且未说明 |
| 21 | 量表名称与版本 | HAMD-17 vs HAMD-24；同一量表两种版本 |
| 22 | 分期 / 分级标准 | Methods 说 AJCC 8th，Results 按 7th 分期 |
| 23 | 仪器 / 试剂型号 | Methods 写 SPSS 26.0，表注写 SPSS 25.0；试剂批号前后不同 |
| 24 | 数据库 / 数据集编号 | 正文 GEO 号与 DAS 中的号不同 |

### 3. 图注 / 表注 vs 正文

| # | 核对项 | 要点 |
|---|---|---|
| 25 | 图注描述的分组数 / 条件数 | 图注说 (A)–(C)，图中实为 (A)–(D) |
| 26 | 图注标的标记含义 | 图中有 \*、#、a/b/c，图注未解释或解释与正文相反 |
| 27 | 图注的统计学描述 | 图注写 "mean ± SEM"，Methods 写 "mean ± SD" |
| 28 | 图注样本量 | 图注 n 与 Results 各组 n 不符 |
| 29 | 表注的单位 | 表头单位与正文不一致（见上 #9） |
| 30 | 表注的缩写定义 | 表中缩写未在表注定义，或定义与正文不同 |
| 31 | 图表标题描述的对象 | 表题写 "baseline characteristics"，表中含随访数据 |
| 32 | 图中坐标轴标签 | 轴标签名称/单位与图注/正文不一致 |
| 33 | 图注引用文献编号 | 图注中 [12] 与正文 [12] 指不同文献 |

### 4. 逻辑与叙述类

| # | 核对项 | 要点 |
|---|---|---|
| 34 | 研究设计自称 | 摘要称 "prospective"，Methods 写 "retrospectively reviewed" |
| 35 | 样本来源 | 摘要说单中心，Methods 出现两家医院 |
| 36 | 主要结局 | Methods 定义的主要结局 vs Results 报告的指标不一致 |
| 37 | 结论强度 | 结论写 "significantly improves survival"，但结果 P=0.08 |
| 38 | 结论 vs 结果方向 | 结果某组更低，结论说更高 |
| 39 | Discussion 引用的本研究数据 | 讨论里重述的数字与 Results 不符 |
| 40 | Limitations 与 Methods 冲突 | Methods 说已双盲，Limitations 说"未设盲" |
| 41 | 亚组 / 敏感性分析 | 提及"见补充材料 Table S3"，但补充材料无此表 |
| 42 | 前后术语 | 同一指标前称 "mortality"，后称 "case fatality rate" |
| 43 | 患者编号 / 病例号 | 同一病例在不同段落编号不同 |
| 44 | 作者/单位信息内部矛盾 | 作者列表 5 人，Author contributions 列 6 人 |

### 5. COI 与机构一致性（★ 与 `ethics-guidelines.md` §3.7 配套）

| # | 核对项 | 位置 A | 位置 B | 红线条件 |
|---|---|---|---|---|
| K1 | **COI 声明 vs 作者机构** ★ | COI 声明（"无利益冲突"） | affiliations（公司名） | 声明无利益但单位含公司 → **矛盾**，标红 `高` |
| K2 | COI 声明 vs Funding | COI 写"无利益冲突" | Funding 写公司资助 | 矛盾 → `不一致` |
| K3 | COI 声明 vs Acknowledgments | COI 写"无利益冲突" | 致谢中出现公司提供药物/设备/写作支持 | 矛盾 → `不一致` |
| K4 | COI 声明自相矛盾 | 同一段先写 "no conflict" | 后写 "Dr. X is an employee of..." | 自相矛盾 → `不一致` |
| K5 | 资助方与作者单位关联 | Funding 的公司名 | 作者单位中的公司名 | 同一公司 → 提示关注（`需核实`） |

> K1/K2/K3/K4 任一项命中 → 「利益冲突声明 COI」在报告中不能记为 `已声明`，
> 须改为 `部分`（声明不全）或标 `不一致`，并触发「要求签署 COI 声明文件」。

---

## 二、执行方法（不靠通读印象，靠机械对照）

1. **建数字台账**：把 Abstract、Results 正文、每张表、每个图注、Discussion 中出现的**每一个关键数字**摘出来，按"指标名"归组，同组内比对。
2. **建术语台账**：分组名、缩写、量表、仪器/软件版本，各建一张小表，看是否只有一种写法。
3. **图注/表注 vs 正文逐条对**：先读图注，再看图中是否真有图注说的事物（组数、标记、误差线、n）。
4. **只报差异，不做解读**：报告里写"位置 A 为 X，位置 B 为 Y"，让作者去裁定哪个对。**不要替作者猜哪个是对的**。

---

## 三、结论取值口径

| 结论 | 什么时候用 | 进修改意见？ |
|---|---|---|
| `一致` | 各位置数值/表述相同 | 否 |
| `不一致` | 明确对不上（数字不同、名称不同、方向相反） | 是，FAIL，高优先级 |
| `需核实` | 表述不同但可能是合理的（如不同亚组用不同缩写、单位换算后等价） | 是，WARN，中优先级 |

> 判 `需核实` 时必须在报告里写清"为什么可能是合理的"，避免误伤。

---

## 四、中英文意见模板

| 情形 | 中文 | English |
|---|---|---|
| 样本量不一致 | 摘要中样本量为 [X]，结果部分为 [Y]，请核对并统一（若存在脱落/排除，请在结果中说明人数及原因）。 | The sample size reported in the Abstract ([X]) does not match that in the Results ([Y]). Please verify and harmonize; if participants were lost to follow-up or excluded, please report the numbers and reasons. |
| P 值不一致 | 结果部分报告 P = [X]，讨论/摘要中为 P = [Y]，请核对统一。 | The P value reported in the Results (P = [X]) differs from that in the Discussion/Abstract (P = [Y]). Please verify and unify. |
| 百分比算不符 | [a]/[b] 对应的百分比应为 [X]%，文中为 [Y]%，请核对。 | The percentage reported ([Y]%) does not correspond to [a]/[b] (which gives [X]%). Please verify. |
| 图注与正文分组数不符 | 图 [X] 的图注描述为 [A] 组，而正文/图中为 [B] 组，请核对图注与图示内容。 | The legend of Figure [X] describes [A] groups, whereas the text/figure shows [B] groups. Please check the legend against the figure content. |
| 图注未解释显著性标记 | 图 [X] 中使用了显著性标记（\*、#、字母），但图注未说明其含义，请补充（如 \* P < 0.05）并注明所用检验方法。 | Figure [X] uses significance markers (\*, #, letters) that are not defined in the legend. Please specify their meaning (e.g., \* P < 0.05) and the statistical test used. |
| 误差线含义不符 | 方法部分说明数据以 mean ± SD 表示，图 [X] 图注为 mean ± SEM，请统一。 | The Methods state that data are presented as mean ± SD, whereas the legend of Figure [X] indicates mean ± SEM. Please harmonize. |
| 研究设计自称矛盾 | 摘要称本研究为前瞻性研究，方法部分描述为回顾性分析，请核对并统一表述。 | The Abstract describes the study as prospective, whereas the Methods describe a retrospective analysis. Please verify and harmonize. |
| 结论与结果方向不符 | 结论指出 [A] 优于 [B]，但结果部分显示 [具体数值/方向相反]，请核对结论表述是否与结果一致。 | The Conclusions state that [A] was superior to [B], but the Results show [opposite direction / non-significant difference]. Please ensure the Conclusions accurately reflect the Results. |
| 软件版本不一致 | 方法部分写 [软件 版本 A]，表注/图注写 [版本 B]，请统一。 | The software version stated in the Methods ([A]) differs from that in the table/figure notes ([B]). Please unify. |
| 引用补充材料不存在 | 正文引用了 [Table S3]，但补充材料中未见该表，请补充或修改引用编号。 | The text cites [Table S3], but no such item is provided in the supplementary material. Please supply it or correct the citation. |
| 缩写前后不一致 | 同一指标在 [位置 A] 写作 [X]，在 [位置 B] 写作 [Y]，请统一。 | The abbreviation for the same measure differs between [location A] ([X]) and [location B] ([Y]). Please use one consistent form. |
