# 文章类型识别与报告指南核查 — v9（甲类 M4 默认启用）

> **v9 变更（2026-11-06）**：本文件服务 SKILL.md 的 **M4 模块，只对甲类（医学/生命科学）稿件启用**。
> 用法：按甲类亚型（RCT / 观察性 / 系统综述 / 动物 / 病例报告 / 方案 / 指南）取对应章节的
> **5–8 项「高频漏项」**逐项判 `已声明 / 部分 / 缺失 / 不适用`，只把 `部分` 与 `缺失` 写进报告。
> **乙类（非医学）不查报告指南**；甲类无法判定亚型时也标 `无法判断`，不硬套。
>
> **不用它判断章节名称、章节数量、章节顺序或版式**——只查"该指南要求讲清楚的内容，稿件讲了没有"。
> 报告口径一律为"该指南条目 X 要求的内容未见"，而非"缺少某某章节"。
> 逐条打分的「全清单复核」属审稿阶段，本工具不做；完整清单在 `guidelines/`，需要时打开核对。

---

## 一、使用流程

```
python <skill目录>/scripts/qc_extract.py <file.docx> <out.txt>
→ 章节序列 + 类型线索（AI 据此判定候选类型）+ 适用指南 + 必核条目
→ 作者复核（脚本仅关键词初筛；置信度"中/低"必须人工确认后才写进意见）
→ 混合类型（RCT+动物实验、Meta+MR）并行适用多套指南
```

脚本路径按本 skill 所在目录自动定位（`GUIDE_DIR` 为脚本同级的 `guidelines/`），不含机器相关硬编码。

---

## 二、类型 → 指南映射

| 文章类型 | 指南 | 本地清单 | 是否打包 |
|---|---|---|---|
| 随机对照试验 | **CONSORT 2025** | `CONSORT-2025-Expanded-Checklist.pdf` / `.docx` | ✅ |
| 观察性研究（队列/病例对照/横断面） | **STROBE** | `STROBE-Checklist-v4-combined.pdf` / 中文版 | ✅ |
| 系统综述 / Meta 分析 | **PRISMA 2020** | `PRISMA-2020-Expanded-Checklist.pdf` / `.docx` | ✅ |
| 研究方案 | **SPIRIT 2025** | `SPIRIT-2025-Expanded-Checklist.pdf` / `.docx` | ✅ |
| 临床实践指南 | **RIGHT**（22 条目） | `RIGHT-Statement-Checklist-22items.pdf` / 中文版 | ✅ |
| 动物实验 | **ARRIVE 2.0** | `ARRIVE-Guidelines-2.0-English.pdf` | ✅ |
| 病例报告 | **CARE** | `CARE-checklist-English-2013.pdf` / 中文版 | ✅ |
| 孟德尔随机化 | STROBE-MR | — | 需线上获取 |
| 诊断准确性 | STARD | — | 需线上获取 |
| 预测模型 | TRIPOD | — | 需线上获取 |
| 质性研究 | COREQ / SRQR | — | 需线上获取 |
| 卫生经济学 | CHEERS | — | 需线上获取 |
| 生信 / 机器学习 | 无统一标准（参照 TRIPOD+AI） | — | 标 N/A |
| 叙述性综述 | 无强制（scoping 用 PRISMA-ScR） | — | 标 N/A |

未打包指南获取入口：EQUATOR Network — https://www.equator-network.org/

---

## 三、各指南「高频漏项」核对表（QC 阶段只看这些）

> 用法：对适用指南，把右列每一条在稿中找一次，落到 `已声明 / 部分 / 缺失 / 不适用`，只把 `部分` 和 `缺失` 写进报告与修改意见。

### CONSORT 2025（RCT）

| 必核项 | 判断标准 |
|---|---|
| 标题/摘要标注 randomised | Title 或 Abstract 出现 randomised/randomized |
| **Trial registration（条目 2）** | 注册平台名 + 号 + URL + 日期，四项齐全 |
| Protocol / SAP 可及性（条目 3） | 给出 protocol 或 SAP 的获取渠道 |
| **受试者流程图（条目 13a）** | 有流程图，各阶段人数 + 排除原因 |
| **Harms（条目 15/19）** | 有不良事件的定义与结果，不是一句"无严重不良事件" |
| ITT / PP 分析集（条目 21b） | 说明纳入分析的人群定义 |
| 主要结局效应量 + 95% CI（条目 17） | 不只报 P 值 |
| 随机化与分配隐藏分开描述（17/18） | 序列生成方法与隐藏机制分开写 |
| Data sharing（条目 4） | 个体去标识数据与统计代码的可及性 |
| CONSORT checklist 随稿 | 是否声明遵循并提交清单 |

### STROBE（观察性研究）

| 必核项 | 判断标准 |
|---|---|
| 标题/摘要标明设计类型 | cohort / case-control / cross-sectional 之一 |
| 研究对象选择与纳入排除（条目 6） | 来源、方法、随访方式清楚 |
| **偏倚控制（条目 9）** | 有实质内容，不是空泛一句 |
| 样本量依据（条目 10） | 说明如何确定 |
| 统计学方法含缺失数据（条目 12c） | 缺失数据如何处理 |
| 各阶段人数（条目 13a/b） | 数字或流程图 |
| **未校正 + 校正估计及 95%CI（条目 16a）** | 两类估计都要给 |
| **局限性（条目 19）** | 讨论偏倚方向与大小 |
| Funding（条目 22） | 资助来源 + 资助方角色 |
| 伦理与知情同意 | 见 `ethics-guidelines.md` |

### PRISMA 2020（系统综述 / Meta 分析）

| 必核项 | 判断标准 |
|---|---|
| 标题标明 systematic review / meta-analysis | — |
| **PROSPERO / OSF 注册号（条目 24）** | 有号；未注册需说明理由 |
| **完整检索式 + 检索日期（条目 7）** | 每个数据库的具体检索式，不是只列库名 |
| **筛选流程图（条目 16a）** | 各阶段记录数 + 排除原因 |
| 偏倚风险评价工具（条目 11） | 明确工具（RoB 2 / ROBINS-I / NOS） |
| 异质性与合并模型（条目 13） | I²、τ²、固定/随机效应选择依据 |
| 发表偏倚评估（条目 14/21） | 漏斗图或 Egger 检验（研究数足够时） |
| 证据确定性（条目 15/22） | GRADE 分级 |
| 数据可用性（条目 27） | — |

### SPIRIT 2025（研究方案）

| 必核项 | 判断标准 |
|---|---|
| 标题含 protocol | 且标明设计、人群、干预 |
| **Trial registration（条目 4）** | 已注册给号；未注册须写拟注册平台 |
| **受试者时间轴（条目 13）** | 有 SPIRIT figure / participant timeline |
| 结局与测量时点（条目 12） | 主要/次要结局各有测量时点 |
| 样本量计算依据（条目 14） | 效应量、α、power |
| **Dissemination policy（条目 8）** | 结果如何传播给受试者与公众 |
| 数据共享（条目 6） | 计划而非已完成 |
| 伦理与知情同意 | — |

### RIGHT（临床实践指南，22 条目 / 7 领域）

| 必核项 | 判断标准 |
|---|---|
| 标题含 guideline/recommendation + 年份（1a/1b） | — |
| 推荐意见摘要（条目 2） | 有 executive summary |
| 目标人群与使用者（7/8） | — |
| 证据检索方法与日期（7a/7b 领域 3） | — |
| **推荐强度 + 证据确定性（13c）** | 每条推荐标注强度与证据级别 |
| 证据到推荐的过程（15） | 共识如何达成 |
| **外审（16）与更新计划（17）** | 是否经独立外审、是否计划更新 |
| **COI 管理（19a/19b）** | 冲突类型、如何评估管理、公众如何获取 |
| 资助来源（18a/18b） | — |

### ARRIVE 2.0（动物实验）

| 必核项 | 判断标准 |
|---|---|
| 种系/品系/性别/年龄/体重/来源（条目 8） | 齐全 |
| **随机化（条目 4）** | 是否随机、如何生成序列 |
| **盲法（条目 5）** | 谁在何阶段知晓分组 |
| **样本量依据（条目 2b）** | 有无 a priori 计算 |
| 纳入排除标准与 n（条目 3） | 各组精确 n |
| **饲养条件（条目 15）** | 笼具、光周期、温湿度、环境丰容 |
| **伦理委员会 + 许可号（条目 14）** | 名称 + 号；未审批须给理由 |
| 人道终点（条目 16c） | 标准、监测指标与频次 |
| 统计方法与假设检验（条目 7） | 软件 + 假设是否检验 |

### CARE（病例报告，13 项）

| 必核项 | 判断标准 |
|---|---|
| 标题含 "case report"（条目 1） | — |
| 关键词含 case report（条目 2） | 2–5 个 |
| 摘要四要素（3a–3d） | 独特性、主要症状、诊断治疗结局、要点 |
| 去标识化患者信息（5a） | — |
| **时间轴（条目 7）** | 以时间线组织诊疗经过 |
| 诊断挑战与鉴别诊断（8b/8c） | — |
| 治疗剂量/疗程/变更理由（9b/9c） | — |
| 随访与不良事件（10b/10d） | — |
| **患者视角（条目 12）** | 独立段落 |
| **知情同意（条目 13）** | 明确书面同意发表 |

---

## 四、跨类型通用项（所有稿件都查）

1. **报告指南声明**：正文或投稿信是否声明遵循了哪套指南；是否随稿提交 checklist
2. **伦理与注册**：见 `ethics-guidelines.md` 的 §零 D1–D10（默认）；深检时才用 §一 完整清单
3. **生成式 AI 披露**：用了 AI 必须声明工具、用途、责任归属；AI 不得署名
4. **数据与代码可及性**：Data Availability 声明（无新数据也须声明）
5. **COI + Funding**：每位作者、资助方角色

---

## 五、意见模板

### 中文

| 情形 | 模板 |
|---|---|
| 类型命中但未声明遵循指南 | 本文为[随机对照试验/观察性研究/系统综述/研究方案/临床实践指南/动物实验/病例报告]，请按 [指南名] 自查，并随修回稿提交填写好的 checklist（标注每项所在页码或行号）。 |
| 类型命中但关键条目缺失 | 按 [指南名] 要求，请补充 [具体条目，如受试者流程图 / 完整检索式 / 患者视角段落]。 |
| 无对应指南 | 本文类型（[类型]）无强制性报告指南，本项不做要求；建议核对期刊作者须知中的数据与代码可及性条款。 |

### English

| Case | Template |
|---|---|
| Guideline not declared | As this manuscript reports a [randomised trial / observational study / systematic review / study protocol / clinical practice guideline / animal study / case report], please ensure that it complies with the [CONSORT 2025 / STROBE / PRISMA 2020 / SPIRIT 2025 / RIGHT / ARRIVE 2.0 / CARE] reporting guideline and submit the completed checklist with your revised files, indicating the page or line number for each item. |
| Key item missing | In accordance with [guideline], please provide [specific item, e.g., the participant flow diagram / the full search strategies for each database / a Patient perspective section]. |
| No applicable guideline | No mandatory reporting guideline applies to this article type. This item is marked as not applicable; please nevertheless ensure that the data and code availability requirements in the Instructions for Authors are met. |

---

## 六、本地清单索引

目录：`<本 skill 目录>/guidelines/`

| 文件 | 说明 |
|---|---|
| `CONSORT-2025-Expanded-Checklist.pdf` / `CONSORT-2025-Checklist.docx` | CONSORT 2025 详版 / 可编辑版 |
| `CONSORT-2025-Flow-Diagram.docx` | 受试者流程图模板 |
| `SPIRIT-2025-Expanded-Checklist.pdf` / `SPIRIT-2025-Checklist.docx` | SPIRIT 2025 |
| `SPIRIT-2025-Participant-Timeline.docx` | 受试者时间轴模板 |
| `PRISMA-2020-Expanded-Checklist.pdf` / `PRISMA-2020-Checklist.docx` | PRISMA 2020 |
| `STROBE-Checklist-v4-combined.pdf` / `STROBE-Checklist-Chinese.pdf` | STROBE 英文合并版 / 中文版 |
| `ARRIVE-Guidelines-2.0-English.pdf` | ARRIVE 2.0（Essential 10 + Recommended Set） |
| `RIGHT-Statement-Checklist-22items.pdf` / `RIGHT-清单-中文简体.pdf` | RIGHT 22 条目 / 中文版 |
| `RIGHT-Statement-Explanation-and-Elaboration.pdf` | RIGHT E&E 全文 |
| `CARE-checklist-English-2013.pdf` / `CARE-checklist-Chinese-2013.pdf` | CARE 中英版 |

来源：consort-spirit.org / prisma-statement.org / strobe-statement.org / arriveguidelines.org / right-statement.org / care-statement.org
