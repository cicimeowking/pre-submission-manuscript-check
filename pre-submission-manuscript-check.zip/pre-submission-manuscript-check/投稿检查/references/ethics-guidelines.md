# 伦理与声明项（Ethics & Declarations）核查指南 — v9

> **v9 变更（2026-11-06）**：本文件**只服务于甲类（医学/生命科学）稿件**。
> SKILL.md 第一步会先做甲/乙二分类：
> - **乙类（非医学）**：医学声明项一律 `不适用`，**不打开本文件**（只查 D1 贡献 / D2 COI / D3 Funding / D4 数据可用性 / D8 AI 披露）。
> - **甲类（医学）**：默认启用 §零 的 D1–D10 + §二/§三 的场景细化（伦理三要素、知情同意四场景、动物、病例报告、注册时间线、AI 披露）。
> - §一 的 32 项完整清单仍是**可选深检**，仅在用户要求"按医学稿件 QC 逐项过一遍"时展开。
>
> **不判断章节形式**：写在 Declarations、Methods 末、脚注、标题页均可，只要能检索到、内容完整。
>
> 配套清单（`guidelines/` 目录）：CONSORT 2025 / SPIRIT 2025 / STROBE / PRISMA 2020 / RIGHT / ARRIVE 2.0 / CARE —— 只在甲类 M4 阶段按亚型取"高频漏项"时使用，不做全条目打分。

---

## 零、甲类默认检查范围（D1–D10，与 SKILL.md 第八节一致）

| # | 声明项 | 何时必需 | 合格底线 |
|---|---|---|---|
| D1 | Author contributions | 所有稿件 | 与作者列表一一对应 + 有实质分工 |
| D2 | Conflict of interest | 所有稿件 | 每位作者的 COI，或明确"无利益冲突" |
| D3 | Funding | 所有稿件 | 机构全称 + 项目号；无资助也须声明 |
| D4 | Data availability | 所有稿件 | 数据去向清楚 |
| D5 | Ethics approval | 涉及人或动物 | 委员会名 + 审批号 + 日期，三者齐全 |
| D6 | Informed consent | 涉及人体受试者/样本 | 已获同意，或注明批准豁免 + 审批号 |
| D7 | Consent for publication | 含可识别个案信息 | 明确"同意发表" |
| D8 | Generative AI use | 使用 AI 工具 | 工具名 + 用途 + 作者负责 |
| D9 | Trial registration | 临床试验/RCT | 平台 + 号 + 日期 |
| D10 | Review registration | 系统综述/Meta | PROSPERO/OSF 号，未注册须说明 |

**位置不作要求**：写在 Declarations、Ethics、Methods 末尾、脚注、标题页均可，只要能被检索到、内容完整。
下表 §一 若被启用（用户要求深检），判断口径相同：**看内容是否齐全，不看章节名叫什么、排在第几节**。

---

## 一、可选深检：声明项完整清单（非默认，需用户确认后启用）

标注：**必需** = 医学稿件普遍要求；**条件** = 触发条件下必需；**不适用** = 触发条件不成立

| # | 声明项 | 何时必需 | 合格标准（三者缺一即不完整） | 依据 |
|---|--------|---------|---------------------------|------|
| 1 | **Ethical Statement 独立章节** | 全部涉及人或动物研究的稿件（必需） | ①有独立章节，位置在正文后、COI 前 ②有实质内容（非"见 Methods"一句了事） | 期刊通用格式要求 |
| 2 | **伦理委员会名称** | 涉及人体受试者 / 动物 / 人体样本 | 具名机构伦理委员会（IRB / 医院伦理委员会 / IACUC） | 赫尔辛基宣言；ARRIVE 14 |
| 3 | **伦理审批号** | 同上 | 具体编号（如 `2023-045`、`ChiCTR2000028765`、`IACUC-2022-11`） | ARRIVE 14；CARE 13 |
| 4 | **审批日期** | 同上 | 年-月-日 或 年月 | 期刊通用 |
| 5 | **赫尔辛基宣言（人体研究）** | 涉及人体受试者 | 明确写出 "in accordance with the Declaration of Helsinki" | WMA |
| 6 | **知情同意 — 受试者本人** | 全部人体研究（前瞻性） | 明确写出获得书面/口头知情同意 | 赫尔辛基；STROBE；CONSORT |
| 7 | **知情同意 — 法定代理人 / 未成年人** | 受试者为未成年人或无行为能力者 | 写明由父母/法定监护人提供同意 + 儿童本人知情同意（assent） | 儿科伦理规范 |
| 8 | **知情同意 — 病例报告 / 病例系列** | 病例报告、个案影像、可识别信息 | 明确声明已获患者（或监护人）书面知情同意**发表** | CARE 13 |
| 9 | **知情同意 — 回顾性病历 / 豁免** | 使用既往病历、生物样本库样本、匿名化数据 | 写明伦理委员会**批准豁免**知情同意（waiver of consent），并给出审批号 | 通用 |
| 10 | **consent for publication** | 稿件含可识别的个人图像 / 影像 / 罕见特征 | 独立段落声明同意发表 | COPE / CARE |
| 11 | **隐私与去标识化声明** | 病例报告、个案影像、可识别人口学信息 | 声明已去标识化，未公开可追溯信息 | CARE 5a；ICMJE |
| 12 | **临床试验注册号（TRN）** | 任何 RCT / 临床试验 | 注册平台名 + 号 + URL + 注册日期，位置在摘要末或标题页 | CONSORT 2；ICMJE |
| 13 | **试验方案 / 统计分析计划可及性** | RCT | 说明 protocol 与 SAP 可获取渠道 | CONSORT 3 |
| 14 | **系统综述注册号（PROSPERO / OSF）** | 系统综述 / Meta 分析 | PROSPERO 号；未注册须说明理由 | PRISMA 24 |
| 15 | **动物伦理审批** | 任何活体动物实验 | IACUC/伦理委员会名称 + 许可号 + 是否符合 ARRIVE / GB/T 35892 | ARRIVE 14 |
| 16 | **动物福利与安乐死方法** | 动物实验 | 麻醉/安乐死方式、人道终点（humane endpoints） | ARRIVE 16 |
| 17 | **饲养条件（housing & husbandry）** | 动物实验 | 温湿度/光周期/笼具/环境丰容（ARRIVE 15） | ARRIVE 15 |
| 18 | **生物样本来源与同意** | 人体组织、血液、细胞系 | 样本来源（手术残余/库） + 伦理批准 + 患者同意 | 通用 |
| 19 | **细胞系鉴定与支原体检测** | 使用细胞系 | 细胞系来源、鉴定方法、支原体检测 | 期刊通用（医学/肿瘤类） |
| 20 | **生成式 AI 使用披露** | 使用了大语言模型/AI 工具 | 工具名、用途、人工审校说明；AI 不得列为作者 | ICMJE 2023+ |
| 21 | **利益冲突声明（COI）** | 全部稿件（必需） | 每位作者的具体 COI，或明确写无 COI | ICMJE |
| 22 | **资金资助声明（Funding）** | 全部稿件（必需） | 资助机构全称 + 项目号；无资助亦须声明 | ICMJE |
| 23 | **资助方角色（role of funder）** | 有资助时 | 说明资助方是否参与设计/分析/发表决定 | CONSORT 5a；STROBE 22 |
| 24 | **数据可用性声明（DAS）** | 全部稿件（必需） | 存在性 + 数据去向清楚；参考示例见下方 §四 | 期刊通用 |
| 25 | **高通量数据登录号** | 芯片 / RNA-seq / 测序 / 结构数据 | GEO / SRA / ArrayExpress / PDB 登录号 + MIAME 合规 | 期刊数据政策 |
| 26 | **作者贡献（Author contributions）** | 全部稿件（必需） | 每位作者的具体贡献，姓名须与作者列表一致 | ICMJE / CRediT |
| 27 | **致谢（Acknowledgments）** | 全部稿件（必需） | 非作者贡献者已获许可同意致谢 | ICMJE |
| 28 | **第三方资源 / 版权许可** | BioRender / KEGG 通路图 / UK Biobank / 数据库图像 | 许可 URL 或信用行、Application Number | 各资源方条款 |
| 29 | **患者视角（Patient perspective）** | 病例报告 | 独立的患者自述段落（CARE 12） | CARE 12 |
| 30 | **研究方案版本（Protocol version）** | 方案类稿件 | 版本号 + 日期 | SPIRIT 2 |
| 31 | **指南制定相关声明** | 临床实践指南 | 推荐强度、证据等级、COI 管理、外审、更新计划 | RIGHT 13c/16/19 |
| 32 | **利益冲突管理流程（指南类）** | 临床实践指南 | 冲突如何评估与管理、公众如何获取 | RIGHT 19b |

---

## 二、Ethical Statement 的三条硬规则（只针对内容，不针对形式）

### 规则 1：审批信息必须可检索到，但不要求独立成章节

- **不判断**：是否叫 `Ethical statement` / `Ethics` / `Declarations`、是否单独一节、排在第几节。各刊版式不同，本工具不作要求。
- **判断**：全文中能否找到"谁批准的、批号是什么、什么时候批的"。
- 常见可接受位置：独立的 Ethic(s) 段落、Methods 末尾一句、Declarations 区块、标题页脚注。
- Methods 里只有一句"已获批准"且再无审批号/日期 → 标 `部分`（在报告中引原句，提示补全三要素即可，**不要求新建章节**）。
- 完全找不到任何审批表述、而稿件明显涉及人体或动物 → 标 `缺失`。

### 规则 2：一句"已获伦理批准"不算合格

不合格示例（必须标 `部分` 或 `缺失`）：

> ❌ "The study was approved by the ethics committee."（无委员会名、无号、无日期）
> ❌ "This study was conducted in accordance with the Declaration of Helsinki."（只有宣言，无审批）
> ❌ "All procedures followed the institutional guidelines."（无具体审批）

合格示例（可直接引用进报告）：

> ✅ "The study was conducted in accordance with the Declaration of Helsinki and was approved by the Ethics Committee of XX Hospital (Approval No. 2023-045, approved 12 March 2023). Written informed consent was obtained from all participants."
> ✅ "All animal procedures were approved by the Institutional Animal Care and Use Committee of XX University (IACUC Protocol No. 2022-11) and complied with ARRIVE 2.0 guidelines."

### 规则 3：研究类型 → 必需声明项的对应

| 研究类型 | 必需项编号 |
|---|---|
| RCT / 临床试验（人体） | 1,2,3,4,5,6,12,13,21,22,23,24,26,27 |
| 观察性研究（队列/病例对照/横断面，人体） | 1,2,3,4,5,6（或豁免9）,21,22,24,26,27 |
| 病例报告 / 病例系列 | 1,8,10,11,29,21,24,26,27 |
| 系统综述 / Meta 分析 | 14,21,22,24,26,27（人体数据再分析时加 9） |
| 动物实验 | 1,15,16,17,21,22,24,26,27 |
| 细胞/分子/生信（无人体无动物） | 19,21,22,24,25,26,27 |
| 临床实践指南 | 1（如有患者数据）,21,22,24,31,32 |
| 使用 AI 工具（任意类型） | 追加 20 |
| 回顾性病历 / 生物样本库 | 追加 9 |

> 未列出的编号在报告中标 `不适用`，并在「依据」列写明为何不适用（如"非动物实验"）。

---

## 三、各类研究的额外必核点

### 3.1 人体研究（CONSORT / STROBE / CARE）

- 受试者纳入前是否签署同意；儿童是否有 assent
- 是否有伦理委员会全称（不能用"我院伦理委员会"这种无机构名的表述）
- 涉及弱势群体（孕妇、囚犯、认知障碍者）→ 是否说明额外保护措施
- 多中心研究 → 是否列出**各中心**伦理审批（或主中心审批 + 各中心备案）
- 涉及基因数据 / 可穿戴设备数据 → 是否说明数据保护合规

### 3.2 动物实验（ARRIVE 2.0）

| ARRIVE 条目 | 必核内容 | 缺失标注 |
|---|---|---|
| 14 Ethical statement | 伦理审查委员会名称 + 许可/方案号；若未审批须给出理由 | 缺失 |
| 15 Housing and husbandry | 饲养环境、笼具、光周期、温湿度、环境丰容 | 部分 |
| 16a 减轻痛苦措施 | 麻醉/镇痛方案 | 部分 |
| 16b 不良事件 | 预期/非预期不良事件报告 | 部分 |
| 16c 人道终点 | 人道终点标准、监测指标与频次 | 部分 |
| 8 Experimental animals | 种/品系/性别/年龄或发育阶段/体重/来源/健康状态 | 部分 |

> 注意：ARRIVE 14 允许"未寻求伦理批准"但**必须给出理由**——这种情况标 `部分` 而非 `缺失`，并在意见中请作者说明。

### 3.3 病例报告（CARE 12/13）

- **CARE 12 患者视角**：必须有独立的患者自述段落（1–2 段）。国内稿件最常缺 → 标 `缺失`
- **CARE 13 知情同意**：必须是明确的"患者已书面同意发表"表述，而非"已获得患者同意治疗"
- 影像/病理图：是否遮盖可识别特征（眼部、纹身、胎记、罕见面部特征）
- 时间轴（CARE 7）：以时间线形式组织诊疗经过

### 3.4 试验注册（TRN）

- 位置：标题页 或 摘要末尾（两处任一即可，但必须在正文前部可被检索到）
- 完整度：注册平台名 + 注册号 + URL + 注册日期，**四项齐全**才标 `已声明`
- 常见问题：只给 NCT 号无平台名 → `部分`

#### 3.4.1 注册时间线核查（★ 必查，回溯注册 / Retrospective registration）

> **这是投稿前自查最容易被漏掉、后果最严重的一类问题。** 注册号齐全不等于合格——
> 注册日期如果晚于首例受试者入组（或晚于伦理批准），即为**回溯注册**，ICMJE 与 COPE 均视为严重问题，
> RCT 尤其严格（CONSORT 2025 条目 2 要求注册须在首例入组前完成）。

**四步判定法**：

**第 1 步：摘出三个日期**

| 日期 | 从哪里找 | 找不到时 |
|---|---|---|
| **D1 注册日期** | 标题页 / 摘要末 / 注册号后的括号内 / 脚注 | 未写注册日期 → 注册项标 `部分`，无法做时间线判断 |
| **D2 首例入组日期**（first patient enrolled / first participant recruited） | Methods 的 Study design、Participants、招募期（如 "patients were enrolled from March 2021 to June 2022"） | 未写明确日期 → 用**招募期起始月**代替，并注明"按招募期起点推定" |
| **D3 伦理批准日期** | Ethical statement 的 approval date | 未写 → 伦理项标 `部分`，时间线判断降级为 `需核实` |

**第 2 步：比较**

```
D1 注册日期  vs  D2 首例入组日期
    D1 ≤ D2           → 前瞻性注册，合格 → `一致`
    D1 > D2           → 回溯注册 → `不一致`（标红，高优先级）
    相差 ≤ 1 个月      → 仍标 `不一致`，但在意见中给出"如系同月内注册请提供平台记录截图"的缓冲表述
    同月且无法区分先后 → `需核实`

D1 注册日期  vs  D3 伦理批准日期
    D1 ≥ D3           → 正常（先伦理后注册是标准顺序）→ `一致`
    D1 < D3           → 注册早于伦理批准 → `需核实`（可能先登记后补批，需说明）
```

**第 3 步：看作者是否已主动说明**

- 作者若已在文中**明确声明** "retrospectively registered" 或说明注册延迟原因 → 状态仍判 `不一致`，
  但意见改为「请补充说明 + 确认已在 Discussion/Limitations 中披露」，优先级由 `高` 降为 `中`
- 作者**完全未提** → 优先级 `高`，必须进修改意见（这是作者投稿前的合规自查责任）

**第 4 步：写入报告**

- 报告 `Internal Consistency Check` 表加一行：
  `["注册日期 vs 首例入组", "Registration: 2021-08-15", "Enrolment start: 2021-03", "不一致"]`
- `checkItems` 中归入「伦理与声明」类，状态 `FAIL`，备注写明两个日期原文
- 中英文意见按 §六「回溯注册」模板生成

**各类型严格度**：

| 文章类型 | 回溯注册的处理 |
|---|---|
| RCT（CONSORT） | **严格禁止**，必须作者说明；无说明则 `FAIL` + `高` |
| 其他前瞻性临床试验 | 严格，同上 |
| 观察性研究（STROBE） | 期刊通常不强制注册；若已注册且为回溯，标 `需核实` + `中` |
| 系统综述（PRISMA） | PROSPERO 注册晚于检索开始 → `不一致` + `中`（PRISMA 24 要求注册先于检索） |
| 回顾性研究 | 不适用（本身即回溯，无"注册在先"要求）→ `不适用` |

**常见狡猾写法（要认出来）**：

- 只写注册号、**不写注册日期** —— 最常见，用注册号去平台查会超范围，先标 `部分`
- 写 "registered" 但日期在招募期之后，且未解释
- 招募期写 "2020–2022"，注册写 2021 —— 起点推定 2020，属回溯
- 用伦理批准日期冒充注册日期
- 注册号对应的平台记录已被更新（如 NCT 的 "First posted" 与 "Study Start" 不同），
  应取 **first posted date** 作为 D1，不是最后更新日期

### 3.5 生成式 AI 披露（ICMJE 2023+）

- 触发：正文/Methods 出现 ChatGPT、GPT-4、Claude、Gemini、LLM、AI-assisted editing 等
- 必需：工具名称与版本、用途（语言润色/图像生成/数据分析）、作者对内容负全责的声明
- **AI 不得列为作者** → 若作者列表出现 AI 名称，标 `缺失` 并列为高优先级

### 3.6 第三方资源许可

| 资源 | 触发 | 需要什么 |
|---|---|---|
| BioRender | 图注/正文提及 | 许可 URL 或 `Created in BioRender: https://BioRender.com/xxxx` 信用行 |
| KEGG 通路图 / Pathway ID | 出现通路图或 `map00xxx` | 版权许可申请表 + 信用行 |
| GO / KEGG 富集分析 | Methods 提及 | 官方数据库 URL + 原始文献引用 |
| UK Biobank | 使用其数据 | 资源致谢 + Application Number |
| PDB / TCGA / GEO 图像 | 复用他人图像 | 许可条款确认 |

### 3.7 利益冲突（COI）声明内容分级 ★

> COI 不只是"有没有一句声明"，而要**读内容分级**。
> 声明为 L2 → 提示作者准备签署的 COI 声明文件（如 ICMJE Disclosure Form）。
> **不核查作者单位**（见下方"第 2 路"）。

#### 第 1 路：COI 声明内容分级

**先确认声明存在**（矩阵第 21 项），再读声明原文，按内容分级：

| 级别 | 声明内容举例 | 处理 |
|---|---|---|
| **L0 无利益相关** | "The authors declare no conflict of interest." / "All authors have nothing to disclose." | 只需声明存在 → `已声明`，不需表格 |
| **L1 学术资助** | 政府基金 / 基金会 / 高校内部经费（NSFC、NIH、Wellcome 等） | 资助写进 Funding 即可，不强制 COI 表格 → `已声明` |
| **L2 存在利益相关** | 出现以下任一关键词：公司雇佣 / 顾问（consultant, advisor）/ 讲课费（speaker fee, honoraria）/ 差旅赞助（travel support）/ 持股（stock, shares, equity）/ 专利（patent, royalties）/ 公司资助的试验（company-sponsored）/ 与企业合作项目 | **必须签署 COI 声明文件** → 声明本身 `已声明`，但报告追加一条 FAIL/WARN：「请提供签署的利益冲突声明表」 |

**L2 关键词扫描表**（对 COI 声明原文 + Funding 原文 + 正文 Acknowledgments 扫描）：

```
employment, employee, consultant, advisory board, advisor, speaker bureau,
honoraria, lecture fee, travel support, travel grant, stock, shares, equity,
patent, royalty, founder, board member, sponsored by, funded in part by
[A-Z][a-z]+ (Pharma|Biotech|Diagnostics|Medical|Therapeutics|Biosciences)
```

**特殊情况**：COI 声明里逐条列出公司名与作者对应关系的（如 "Dr. X is an employee of A Pharma"）
——声明详细是好事，但**正因为有真实利益，必须配合签署的 COI 表格**，缺表格即 WARN。

#### 第 2 路：作者单位性质（不查，改为提示作者自查）

v8 起本工具**不读取、不推断作者单位的性质**（单位信息属作者身份信息，且需要外部核实）。

只在报告里保留一句固定提示，供作者自行判断：

> 如任一作者单位为**企业/公司型机构**（药企、器械商、CRO、生物技术公司等），请确认 COI 声明已如实反映该关系，并准备好签署的 COI 声明文件。

作者自行确认即可，本工具不扫描关键词、不作为 FAIL 依据、不在报告中列出单位名称。

#### 触发矩阵（只看声明内容，不看作者单位）

| COI 声明内容 | 结论 |
|---|---|
| L0 无利益 | 只需声明存在，不要求表格 |
| L1 学术资助 | 资助写进 Funding 即可，不要求表格 |
| **L2 有利益**（公司雇佣/顾问/讲课费/持股/专利/公司资助） | **要求签署 COI 声明文件**（FAIL，高） |
| 全文无任何 COI 表述 | `缺失`（FAIL，高）——最优先问题 |
| COI 声明自相矛盾（先写"无"后写"某作者为某公司雇员"） | `不一致`（FAIL，高） |

#### 报告输出

- `declMatrix` 中「利益冲突声明 COI」行照常填状态，依据列摘录原文
- `checkItems` 新增一行（类别「伦理与声明」）：
  - 触发 L2 → `["伦理与声明","FAIL","需签署 COI 声明文件","COI 声明提及 [利益类型]，请提供所有作者签署的利益冲突声明表","高"]`
  - L0 → 不新增行
- 意见模板见 §六「COI 表格」三条

---

## 四、Data Availability 声明（存在性检查 + 通用参考示例）

Data Availability Statement 为**必需声明**（即使无新数据产生也须声明）。各期刊对措辞与放置位置要求不同，本技能**仅检查「是否存在 + 是否清楚说明数据去向」**，不强制套用特定期刊模板；具体措辞以目标期刊 Author Guidelines 为准。

以下为学术出版常见表述，**仅作参考示例**，供作者按目标期刊改写（非硬性模板，不要求逐字命中）：

1. 数据含于公共库：The data that support the findings of this study are available in the [NAME] repository.
2. 受限不可公开：The datasets generated and/or analyzed during the current study are not publicly available due to [REASON] but are available from the corresponding author on reasonable request.
3. 应要求提供：The datasets generated and/or analyzed during the current study are available from the corresponding author on reasonable request.
4. 不适用/无新数据：Data sharing is not applicable to this article as no datasets were generated or analyzed during the current study.
5. 文内/补充材料：All data generated or analyzed during this study are included in this published article [and its supplementary information files].

> 完全没有 DAS 章节 → `缺失`。有声明但措辞自由发挥、能清楚说明数据去向 → 不判错，仅提示对照目标期刊措辞。

---

## 五、标注口径（报告中 Declaration Matrix 用的四种状态）

| 状态 | 含义 | 是否进修改意见 |
|---|---|---|
| `已声明` | 要素齐全，可直接引原文 | 否 |
| `部分` | 有声明但缺关键要素（如无审批号） | 是（WARN 级） |
| `缺失` | 应声明而未声明 | 是（FAIL 级，高优先级） |
| `不适用` | 触发条件不成立 | 否（须在依据列写明理由） |

---

## 六、中英文意见模板（按需取用，避免机械套用）

| 情形 | 中文 | English |
|---|---|---|
| 伦理审批信息缺失 | 请补充伦理委员会全称、审批号与审批日期（写在现有伦理表述处或 Declarations 中均可，不要求单独成节）。 | Please provide the full name of the ethics committee, the approval number and the approval date (wherever the ethics statement currently sits; a separate section is not required). |
| 只有"已批准"无审批号 | 现有伦理表述只写了"已通过伦理审批"，请补充伦理委员会全称、审批号和审批日期；仅写"已批准"无法核实。 | The current statement only indicates that the study was approved. Please provide the full name of the ethics committee, the approval number and the approval date. |
| 涉及人体受试者无知情同意 | 本研究涉及人体受试者，请在伦理声明中明确说明已获得所有受试者的知情同意（如为回顾性研究并获豁免，请注明"经伦理委员会批准豁免知情同意"及审批号）。 | As this study involves human participants, please state in the Ethical Statement that informed consent was obtained from all participants. If consent was waived for this retrospective study, please state that the waiver was approved by the ethics committee and provide the approval number. |
| 病例报告无患者视角 | 按 CARE 指南第 12 条，请补充独立的 "Patient perspective" 段落（1–2 段患者自述）。 | In accordance with item 12 of the CARE checklist, please add a separate "Patient perspective" section (one to two paragraphs in the patient's own words). |
| 病例报告知情同意表述不当 | 请将知情同意表述修改为明确"已获得患者书面知情同意发表本文及相关图像"（CARE 第 13 条）。 | Please revise the consent statement to state explicitly that written informed consent for publication of this case report and any accompanying images was obtained from the patient, as required by item 13 of the CARE checklist. |
| 动物伦理信息不全 | 请补充动物伦理委员会名称与许可/方案编号，以及饲养条件、麻醉与安乐死方式、人道终点（ARRIVE 2.0 第 14–16 条）。 | Please provide the name of the animal ethics committee and the licence/protocol number, together with housing and husbandry conditions, anaesthesia and euthanasia methods, and humane endpoints, in accordance with items 14–16 of ARRIVE 2.0. |
| 缺 TRN | 请在标题页或摘要末尾补充试验注册平台名称、注册号、注册网址与注册日期。 | Please provide the name of the trial registry, the registration number, the registry URL and the date of registration on the title page or at the end of the abstract. |
| 缺 PROSPERO | 本文为系统综述，请补充 PROSPERO 注册号；如未注册，请在回复中说明理由。 | As this is a systematic review, please provide the PROSPERO registration number. If the review was not registered, please state the reason in your response. |
| DAS 缺失 | 请补充 Data Availability 声明（即使未产生新数据也需声明，可用"Data sharing is not applicable..."模板）。 | Please add a Data Availability Statement. A statement is required even when no new data were generated; in that case the wording "Data sharing is not applicable to this article as no datasets were generated or analyzed during the current study" may be used. |
| 生成式 AI 未披露 | 如写作过程中使用了 AI 工具，请在文末补充声明，注明工具名称、用途及作者对全文内容负责；AI 不得列为作者。 | If AI tools were used in the preparation of this manuscript, please add a statement specifying the tool(s) used, the purpose, and that the authors take full responsibility for the content. AI tools must not be listed as authors. |
| 审批号与注册号矛盾 | 伦理声明中的审批号/日期与注册信息不一致，请核对并统一。 | The approval number/date given in the Ethical Statement does not match the registration record. Please verify and harmonize the two. |
| **COI 有利益相关·需表格** | 利益冲突声明中提及 [利益类型：公司雇佣/顾问/讲课费/持股/公司资助试验等]，请提供**全部作者签署的利益冲突声明文件**（ICMJE Disclosure Form 或期刊指定模板），随修回稿一并提交。 | The Conflict of Interest statement mentions [type of interest: employment/consultancy/honoraria/stock ownership/company-sponsored trial]. Please provide a **signed Conflict of Interest declaration form (e.g., the ICMJE disclosure form)** from **all authors** and submit it together with the revised files. |
| **COI 自查提示（非 FAIL，可选写入报告）** | 如任一作者单位为**企业/公司型机构**，请自行确认现有 COI 声明已完整反映该关系，并准备全部作者签署的利益冲突声明文件。 | If any author affiliation is a commercial entity, please confirm that the COI statement fully reflects that relationship and prepare signed declarations from all authors. |
| **回溯注册（注册晚于入组）** | 稿件标注的注册日期为 [YYYY-MM-DD]，而 Methods 中受试者招募始于 [YYYY-MM]，注册晚于首例受试者入组，属于**回溯注册**。请在文中明确说明注册延迟的原因，并在 Discussion 或 Limitations 中作为局限披露；如为同月内完成注册，请提供注册平台的首次发布记录以便核实。 | The registration date given ([YYYY-MM-DD]) postdates the start of participant enrolment ([YYYY-MM]); the trial was therefore **retrospectively registered**. Please explain the reason for the delayed registration and disclose it as a limitation in the Discussion. If registration was completed within the same month, please provide the registry's first-posted record for verification. |
| **回溯注册·作者已披露** | 稿件已说明为回溯注册，请确认该局限已在 Discussion 或 Limitations 中明确披露，并补充注册延迟的具体原因。 | The retrospective nature of the registration is acknowledged. Please ensure that this limitation is explicitly discussed in the Discussion or Limitations section, and state the reason for the delay. |
| **注册早于伦理批准** | 注册日期（[YYYY-MM]）早于伦理批准日期（[YYYY-MM]），请核对两者时间顺序，并说明伦理批准前完成注册的原因。 | The registration date ([YYYY-MM]) precedes the ethics approval date ([YYYY-MM]). Please verify the sequence and explain why registration was completed before ethical approval. |
| **只给注册号无注册日期** | 稿件提供了注册号 [XXX]，但未给出注册日期，请补充注册日期（以注册平台首次发布日为准），以便核对注册是否早于首例入组。 | The registration number ([XXX]) is provided, but the date of registration is not. Please supply the registration date (as first posted on the registry) so that it can be verified that registration preceded first participant enrolment. |

---

## 六之二、优先级与标红规则

报告中「优先级」列与状态颜色需按以下规则确定，**回溯注册属最高级**。

| 情形 | 状态 | 优先级 | 报告颜色 |
|---|---|---|---|
| 回溯注册（D1 > D2），作者未说明 | `FAIL` | **高** | 红 |
| 回溯注册，作者已主动披露但未写原因 | `FAIL` | 中 | 红 |
| 注册早于伦理批准 | `WARN` | 中 | 橙 |
| 只给注册号无注册日期 | `WARN` | 中 | 橙 |
| 注册项完全缺失 | `FAIL` | **高** | 红 |
| 前瞻性注册（D1 ≤ D2） | `PASS` | — | 绿 |

> **标红判定实现**：写入 `checkItems` 时把优先级放在第 5 位（`"高"`），
> `qc_report_gen.js` 的 Issue Summary 会将该行 Priority 单元格渲染为红色（COLOR_RED = `C0392B`）。
> 同时 Prompt 在对话输出的「检查结果汇总」中，该行需前置 `🔴` 标记。

---

## 七、填写报告时的操作顺序

1. 先跑 `qc_extract.py`，看 stdout 的「声明项关键词命中」——**命中≠合格**，只作为定位线索
2. **默认**按 §零 的 D1–D10 逐项判定状态（`已声明` / `部分` / `缺失` / `不适用`）；用户要求深检时才用 §一的完整清单
3. 对每个 `部分` / `缺失`：摘录原文位置与关键句，写入 `declMatrix` 第三列（**复述内容即可，不回显邮箱/电话/地址**）
4. 按 §六 选模板，生成中文意见（交付只出中文；用户要求才附英文），**同编号**
5. `不适用` 项必须在依据列写清理由，否则作者无法判断是漏检还是真不需要
6. 判"缺"之前先通读一遍全文：审批信息可能写在 Methods 末、脚注或 Declarations 里，不要因为没看到独立标题就判缺失
