# -*- coding: utf-8 -*-
"""
脱敏核验脚本（**可选**：仅在用户主动要求"隐私模式"时运行）。

v2 说明：默认流程**不再执行**本脚本。原因：作者与署名检查需要核对标题页作者全名
与 Author Contributions 的一一对应，强制脱敏会把待查信息删掉。
只在用户明确表示"不想让作者信息进入分析"时，才跑本脚本并按其结论暂停或继续。

扫描稿件 docx，检测是否残留疑似敏感信息（作者联系方式 / ORCID /
通讯标识 / 单位机构名称等）。设计为"只输出命中类别计数，绝不输出命中原文"，
因此模型只会看到计数与 CLEAN / SUSPECTED 结论，不会接触到具体姓名、邮箱、地址等。

命中强信号（email / ORCID / 标题页区机构关键词）即判定 SUSPECTED_SENSITIVE，
调用方须暂停检查并要求用户重新上传脱敏稿。

用法:
    python desensitize_check.py <input.docx>

输出（仅摘要，不含任何命中原文）:
    DESENSITIZE_CHECK: {"email":N,"orcid":N,"phone":N,"affiliation_kw":N,"front_matter_found":bool}
    RESULT: CLEAN | SUSPECTED_SENSITIVE
    NOTE: <可选说明，如未能隔离标题页时提示人工核实>

说明（局限性，务必如实传达）:
    - 本脚本为"尽力而为"的自动筛查，不保证识别所有形式的敏感信息
      （如仅剩作者姓名缩写而无单位/邮箱、被改写为占位符等情况可能无法识别）。
    - 命中类别计数本身也是敏感信号的间接证据，但不含原文；模型据此决定是否熔断，
      不会读取或分析具体敏感内容。
    - 最终是否脱敏充分，仍需用户在本地自行确认。
"""
import os
import re
import sys

from docx import Document

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'


def full_text(elem):
    """递归收集 elem 内所有 <w:t> 文本（含超链接/域内文字），跳过 w:del 修订删除。"""
    parts = []
    for t in elem.iter('{%s}t' % W_NS):
        anc = t.getparent()
        in_del = False
        while anc is not None:
            if anc.tag == '{%s}del' % W_NS:
                in_del = True
                break
            anc = anc.getparent()
        if in_del:
            continue
        parts.append(t.text or '')
    return ''.join(parts)


EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
ORCID_RE = re.compile(r"\b0000-000[0-9]-[0-9]{4}-[0-9]{3}[0-9X]\b")
# 电话为弱信号（仅作提示，不参与熔断），限制在标题页区域统计
PHONE_RE = re.compile(r"(?:\+\d{1,3}[\s\-]?)?(?:\(?\d{2,4}\)?[\s\-]?){2,}\d{3,4}")
# 机构关键词（仅在标题页区域统计，避免参考文献中大量 "University" 误报）
AFFIL_KW = re.compile(
    r"\b(University|Universities|Institute|Institutes|College|Colleges|"
    r"Hospital|Hospitals|School of|Department of|Laboratory|Academy)\b",
    re.I,
)


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: desensitize_check.py <input.docx>")
    path = sys.argv[1]
    if not os.path.isfile(path):
        sys.exit("错误：找不到稿件文件 → %s" % path)
    try:
        doc = Document(path)
    except Exception as e:
        sys.exit("错误：无法解析该 .docx（请确认是有效的 Word 文件）→ %s" % e)
    paras = [full_text(p._p) for p in doc.paragraphs]

    # 定位标题页（正文起点）：首个 Abstract / Introduction 标题之前视为 front matter。
    # 典型 docx 中标题、作者、单位、通讯信息、running head 都在 Abstract 之前。
    front_end = len(paras)
    for i, t in enumerate(paras):
        s = t.strip()
        if re.match(r"(?i)^(abstract|introduction)\b", s) or s.lower() in ("abstract", "introduction"):
            front_end = i
            break
    front_matter = paras[:front_end]
    front_text = "\n".join(front_matter)
    body_text = "\n".join(paras[front_end:])

    # email / ORCID 全篇扫描（参考文献中极少见作者邮箱/ORCID，精度高）
    email = len(EMAIL_RE.findall(front_text)) + len(EMAIL_RE.findall(body_text))
    orcid = len(ORCID_RE.findall(front_text)) + len(ORCID_RE.findall(body_text))
    phone = len(PHONE_RE.findall(front_text))
    # 机构关键词只在标题页区域统计，避免参考文献中大量 "University" 误报
    affil = len(AFFIL_KW.findall(front_text))

    front_found = front_end < len(paras)
    summary = {
        "email": email,
        "orcid": orcid,
        "phone": phone,
        "affiliation_kw": affil,
        "front_matter_found": front_found,
    }
    print("DESENSITIZE_CHECK:", summary)

    notes = []
    # 强信号熔断：email / ORCID 全篇命中，或（已成功隔离标题页时）标题页机构关键词命中。
    # 若未能隔离标题页（front_found=False），机构关键词统计覆盖全文会误报，故不参与熔断。
    suspected = (email > 0) or (orcid > 0) or (affil > 0 and front_found)
    if not front_found:
        notes.append(
            "未能在稿件中定位 Abstract/Introduction 标题以隔离标题页，"
            "机构关键词未参与判定；请人工确认脱敏是否充分。"
        )
    if phone > 0:
        notes.append(
            f"标题页区域检测到 {phone} 处疑似电话号码格式，仅供参考，"
            "请人工核实是否需脱敏。"
        )
    for n in notes:
        print("NOTE:", n)

    print("RESULT:", "SUSPECTED_SENSITIVE" if suspected else "CLEAN")


if __name__ == "__main__":
    main()
