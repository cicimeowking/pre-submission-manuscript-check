# -*- coding: utf-8 -*-
"""
提取 docx 稿件中的参考文献列表 + 正文引用位置映射。
用法:
    python extract_citations.py <input.docx> <output.json> [--refs-heading "References"] [--max-refs N]

输出 JSON: [{"num":1,"ref":"完整文献条目","ctxs":[{"para":段号,"sentence":"引用句"}, ...]}, ...]
同时打印校验信息：引用标记总数、每条文献被引段落、未被引用的文献。
"""
import json
import re
import sys
import argparse

CITE_RE = re.compile(r"\[(\d+(?:\s*[-,–]\s*\d+)*)\]")
PROTECT = re.compile(
    r"\b(Fig|Figs|e\.g|i\.e|et al|vs|etc|No|al|St|Mt|cf|ca|Suppl|Suppl\.)\b\.|(?-i:[B-Z])\.(?=\s+[a-z])",
    re.I,
)

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

def full_text(elem):
    """递归收集 elem 内所有 <w:t> 文本（含超链接/域内的文字）。

    ⚠️ python-docx 的 paragraph.text / cell.text 会漏掉超链接 (w:hyperlink)
    内部的 run，可能造成正文引用句或文献条目被抽空而误报。本函数规避之；
    同时跳过 w:del 修订删除内容。
    """
    parts = []
    for t in elem.iter('{%s}t' % W_NS):
        anc = t.getparent()
        in_del = False
        while anc is not None:
            if anc.tag == '{%s}del' % W_NS:
                in_del = True
                break
            anc = anc.getparent()
        if in_del:
            continue
        parts.append(t.text or '')
    return ''.join(parts)


def parse_nums(inner):
    nums = set()
    for part in inner.replace("–", "-").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            try:
                a, b = part.split("-")
                nums.update(range(int(a), int(b) + 1))
            except ValueError:
                continue
        else:
            try:
                nums.add(int(part))
            except ValueError:
                continue
    return sorted(nums)


def split_sentences(text):
    protected = []
    def repl(m):
        protected.append(m.group(0))
        return f"\x00{len(protected) - 1}\x00"
    t = PROTECT.sub(repl, text)
    parts = re.split(r"(?<=[.!?])\s+", t)
    out = []
    for p in parts:
        def back(m):
            try:
                return protected[int(m.group(1))]
            except IndexError:
                return ""
        out.append(re.sub(r"\x00(\d+)\x00", back, p))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="docx 路径")
    ap.add_argument("output", help="输出 JSON 路径")
    ap.add_argument("--refs-heading", default="References",
                    help="参考文献标题段文本，默认 'References'")
    ap.add_argument("--max-refs", type=int, default=0,
                    help="参考文献条数上限（可选，用于异常稿件）")
    args = ap.parse_args()

    from docx import Document
    doc = Document(args.input)
    paras = [full_text(p._p) for p in doc.paragraphs]

    # 定位 References 标题段
    refs_start = None
    for i, t in enumerate(paras):
        if t.strip() == args.refs_heading:
            refs_start = i
            break
    if refs_start is None:
        # 回退：找包含参考文献标题的段
        for i, t in enumerate(paras):
            if t.strip().lower().startswith(args.refs_heading.lower()):
                refs_start = i
                break
    if refs_start is None:
        sys.exit(f"未找到参考文献标题段 '{args.refs_heading}'，请用 --refs-heading 指定")

    body = paras[:refs_start]
    refs_raw = [t.strip() for t in paras[refs_start + 1:] if t.strip()]

    # 提取文献条目：优先按行内编号 [N] 前缀；否则按顺序编号
    refs = {}
    order = []
    next_num = 1
    for line in refs_raw:
        # 补充材料标题（Table S*/Fig. S*）或出版方声明紧跟参考文献列表之后，不应作为文献条目提取
        if line.startswith("Table S") or line.startswith("Fig. S") \
           or line.startswith("Disclaimer") or line.startswith("Publisher"):
            break
        m = re.match(r"^\[?(\d+)\]?[\.\)]?\s+(.*)$", line, re.S)
        if m:
            num = int(m.group(1))
            text = m.group(2).strip()
            refs[num] = text
            if num not in order:
                order.append(num)
        else:
            # 无编号行：可能是某条文献的续行，不覆盖已有编号条目（异常稿件兜底）
            while next_num in refs:
                next_num += 1
            refs[next_num] = line
            if next_num not in order:
                order.append(next_num)
            next_num += 1

    if args.max_refs:
        order = [n for n in order if n <= args.max_refs]

    # 提取正文引用上下文
    ref_ctx = {}
    cite_count = 0
    for i, t in enumerate(body):
        if not t.strip():
            continue
        for si, s in enumerate(split_sentences(t)):
            for m in CITE_RE.finditer(s):
                nums = parse_nums(m.group(1))
                if not nums:
                    continue
                cite_count += 1
                for n in nums:
                    ref_ctx.setdefault(n, []).append({"para": i, "sentence": s.strip()})

    # 组装
    data = []
    uncited = []
    for n in order:
        if n in refs:
            ctxs = ref_ctx.get(n, [])
            if not ctxs:
                uncited.append(n)
            data.append({"num": n, "ref": refs[n], "ctxs": ctxs})

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)

    print(f"References heading at para {refs_start}; total refs: {len(data)}; "
          f"citation markers in body: {cite_count}")
    print("Uncited refs:", uncited if uncited else "none")

    # 表格内引用提示
    try:
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    ct = full_text(cell._tc)
                    if CITE_RE.search(ct):
                        print("WARN: 表格单元格中发现引用标记:", ct.strip()[:80])
                        break
    except Exception:
        pass


if __name__ == "__main__":
    main()
