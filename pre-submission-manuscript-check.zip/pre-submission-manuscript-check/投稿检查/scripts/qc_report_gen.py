# -*- coding: utf-8 -*-
"""
投稿前自查报告生成器（python-docx 版）。

用法:
    python qc_report_gen.py --config <config.json>

config.json 字段（与 SKILL.md 中 qc_report_gen.js 的 JSON 契约一致）:
    articleTitle     文章英文标题
    articleTitleCN   文章中文标题（可选）
    manuscriptFile   原稿件文件名（不含作者身份信息）
    articleType      文章类型（如 Research Article / Review，由 AI 识别后填入）
    flowType         检查流程（可选）：甲类（医学…）｜G + M  或  乙类（非医学）｜G
                     显示在封面，作为"先二分类再分流"是否执行的凭证
    desensitized    （已废弃）旧配置传入会被静默忽略；封面不再显示脱敏状态
    checkDate        检查日期
    checkTool        检查工具
    articleStats     {"abstractWords":int,"bodyWords":int,"figures":int,"tables":int}（可选）
    checkItems       [[类别, PASS/FAIL/WARN/N/A, 检查项, 详细说明, 严重程度?], ...]
    authorTable      [[作者全名, 贡献声明中出现, 贡献条目摘录, 结论], ...]（可选，作者与贡献对照表）
    typoTable        [[编号, 位置, 原文token, 说明, 级别], ...]（可选，书写规范明细表）
    cnItems          [中文修改意见, ...]
    citationIssues   [[文献编号, 引用序号, 判断结论, 所属章节, 判断理由], ...]（可选）
                     仅收录引用恰当性检查中"非相关"的条目，渲染为报告第 5 节
    citationStats    {"refs":int,"citations":int,"issues":int}（可选，第 5 节统计行）
    citationNote     第 5 节补充说明（可选）
    limitations     [检查局限性 / 需人工核实事项, ...]（可选，渲染为报告末节）
    outputPath       输出 .docx 路径

输出语言：**仅中文**（v2.1 起取消英文修改建议节）。为兼容旧配置，若仍传入
enItems 字段会被静默忽略，不报错。

隐私约束：报告可引用**作者姓名**（作者与 Author Contributions 一一对应检查需要），
但不得包含邮箱、电话、ORCID、通讯地址、身份证号、患者可识别信息。

统计数字（total/pass/fail/warn/na）由脚本自动派生，手填会被覆盖。
"""
import argparse
import json
import os
import sys

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Cm

FONT_ZH = '微软雅黑'
FONT_EN = 'Times New Roman'

RESULT_COLOR = {
    'PASS': RGBColor(0x00, 0x70, 0x00),
    'FAIL': RGBColor(0xC0, 0x00, 0x00),
    'WARN': RGBColor(0xBF, 0x60, 0x00),
    'N/A': RGBColor(0x59, 0x59, 0x59),
}
PRIORITY_CN = {'高': '高', '中': '中', '低': '低'}


def parse_item(x):
    """cnItems 支持两种写法：
    - 纯字符串 -> 必改项（mandatory）
    - {"text": "...", "advisory": true} -> 建议项（对应 WARN/建议级）。
      生成时自动置于该节末尾，并加【建议】显著标注，方便按需取舍。
    """
    if isinstance(x, dict):
        return x.get('text', ''), bool(x.get('advisory', False))
    return x, False


def _comment(doc, label, body, tag=None):
    """渲染一条修改意见：label 为序号前缀（如 '1. '），body 为正文；
    tag 非空时在序号与正文之间插入橙色加粗的“【建议】”标注。"""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(label)
    r.font.size = Pt(10.5)
    r.font.bold = True
    r.font.name = FONT_EN
    if tag:
        rt = p.add_run(tag)
        rt.font.size = Pt(10.5)
        rt.font.bold = True
        rt.font.name = FONT_EN
        rt.font.color.rgb = RESULT_COLOR['WARN']
    r2 = p.add_run(body)
    r2.font.size = Pt(10.5)
    r2.font.name = FONT_EN
    r2._element.rPr.rFonts.set(qn('w:eastAsia'), FONT_ZH)
    return p


def _shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:fill'), hexcolor)
    tcPr.append(shd)


def set_cell(cell, text, size=9, bold=False, color=None, align=None, font=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(2)
    if align is not None:
        p.alignment = align
    run = p.add_run(str(text))
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.name = font or FONT_EN
    run._element.rPr.rFonts.set(qn('w:eastAsia'), FONT_ZH)
    if color is not None:
        run.font.color.rgb = color


def add_table(doc, header, rows, widths=None, header_fill='D9E2F3'):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = t.rows[0].cells
    for i, h in enumerate(header):
        set_cell(hdr[i], h, size=9, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
        _shade(hdr[i], header_fill)
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            set_cell(cells[i], v, size=8.5)
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths):
                row.cells[i].width = Cm(w)
    return t


def h(doc, text, level=1, size=None, space_before=12):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(text)
    run.font.size = Pt(size or (14 if level == 1 else 12))
    run.font.bold = True
    run.font.name = FONT_EN
    run._element.rPr.rFonts.set(qn('w:eastAsia'), FONT_ZH)
    run.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
    return p


def para(doc, text, size=10.5, bold=False, italic=False, align=None, space_after=6):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = FONT_EN
    run._element.rPr.rFonts.set(qn('w:eastAsia'), FONT_ZH)
    return p


def _guess_priority(item):
    result, name = item[1].upper(), item[2]
    detail = item[3] if len(item) > 3 else ''
    if result == 'WARN':
        return '低'
    if any(k in name or k in detail for k in ('缺失', '缺', 'missing', 'Missing')):
        return '高'
    return '中'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', required=True)
    args = ap.parse_args()

    cfg = json.load(open(args.config, encoding='utf-8'))

    items = cfg.get('checkItems', [])
    norm = []
    for it in items:
        it = list(it) + [None] * (5 - len(it))
        cat, res, name, detail, pri = it[0], it[1].upper(), it[2], it[3], it[4]
        if not pri:
            pri = _guess_priority(it)
        norm.append([cat, res, name, detail, pri])

    total = len(norm)
    counts = {'PASS': 0, 'FAIL': 0, 'WARN': 0, 'N/A': 0}
    for it in norm:
        counts[it[1]] = counts.get(it[1], 0) + 1

    doc = Document()
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Cm(2.2)
    sec.top_margin = sec.bottom_margin = Cm(2.2)

    # ---------- 封面 ----------
    for _ in range(4):
        doc.add_paragraph()
    para(doc, 'Manuscript Pre-Submission Self-Check Report', size=24, bold=True,
         align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
    para(doc, '投稿前自查报告', size=16, bold=True,
         align=WD_ALIGN_PARAGRAPH.CENTER, space_after=28)

    if cfg.get('articleTitle'):
        para(doc, cfg['articleTitle'], size=12.5, bold=True,
             align=WD_ALIGN_PARAGRAPH.CENTER, space_after=6)
    if cfg.get('articleTitleCN'):
        para(doc, cfg['articleTitleCN'], size=11.5,
             align=WD_ALIGN_PARAGRAPH.CENTER, space_after=30)

    meta = [('Manuscript file / 稿件文件', cfg.get('manuscriptFile', '')),
            ('Article type / 文章类型', cfg.get('articleType', '')),
            ('Check profile / 检查流程', cfg.get('flowType', '')),
            ('Check date / 检查日期', cfg.get('checkDate', '')),
            ('Check tool / 检查工具', cfg.get('checkTool', ''))]
    t = doc.add_table(rows=0, cols=2)
    t.style = 'Table Grid'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for k, v in meta:
        cells = t.add_row().cells
        set_cell(cells[0], k, size=9.5, bold=True)
        set_cell(cells[1], v, size=9.5)
        cells[0].width = Cm(6.0)
        cells[1].width = Cm(10.5)

    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    # ---------- Check Statistics ----------
    h(doc, '1. Check Statistics　检查统计总览', 1)
    add_table(doc,
              ['Total', 'PASS', 'FAIL', 'WARN', 'N/A'],
              [[total, counts['PASS'], counts['FAIL'], counts['WARN'], counts['N/A']]],
              widths=[3.3] * 5)

    # ---------- Detailed Check Results ----------
    h(doc, '2. Detailed Check Results　分类详细检查表', 1)
    stats = cfg.get('articleStats') or {}
    cats = []
    for it in norm:
        if it[0] not in cats:
            cats.append(it[0])
    for cat in cats:
        h(doc, cat, 2, size=11.5, space_before=10)
        if stats and cat.startswith(('章节结构', '结构完整性')):
            add_table(doc, ['Item / 项目', 'Value / 数值'],
                      [['Abstract word count / 摘要字数', f"{stats.get('abstractWords', '-')} words"],
                       ['Main text word count / 正文字数', f"{stats.get('bodyWords', '-')} words"]],
                      widths=[8.0, 8.5])
            doc.add_paragraph()
        if stats and cat.startswith('图表'):
            figs = stats.get('figures', 0)
            tabs = stats.get('tables', 0)
            note = ''
            if figs + tabs > 10:
                note = '（总数 > 10，建议精简或移入补充材料）'
            add_table(doc, ['Item / 项目', 'Count / 数量'],
                      [['Figures / 图', figs], ['Tables / 表', tabs],
                       ['Total / 合计', f'{figs + tabs}{note}']],
                      widths=[8.0, 8.5])
            doc.add_paragraph()
        rows = []
        for it in norm:
            if it[0] == cat:
                rows.append([it[2], it[1], it[3]])
        t = add_table(doc, ['Check Item / 检查项', 'Result / 结果', 'Detail / 详细说明'], rows,
                      widths=[4.2, 2.0, 10.3])
        idx = 0
        for it in norm:
            if it[0] != cat:
                continue
            idx += 1
            c = t.rows[idx].cells[1]
            c.text = ''
            p = c.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(it[1])
            r.font.size = Pt(8.5)
            r.font.bold = True
            r.font.name = FONT_EN
            r.font.color.rgb = RESULT_COLOR.get(it[1], RGBColor(0, 0, 0))

    # ---------- 作者与贡献对照表（可选）----------
    author_rows = cfg.get('authorTable') or []
    secn = 3
    if author_rows:
        doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        h(doc, '%d. Author List vs Author Contributions　作者与贡献对照表' % secn, 1)
        para(doc, '仅核对稿件内部是否自洽（人数、姓名、顺序）；不代表对贡献分配的学术评价。',
             size=9, italic=True, space_after=6)
        rows = []
        for a in author_rows:
            a = list(a) + [''] * (4 - len(a))
            rows.append([a[0], a[1], a[2], a[3]])
        add_table(doc, ['作者（标题页全名）', '贡献声明中出现', '贡献条目摘录', '结论'],
                  rows, widths=[4.2, 2.6, 7.2, 2.5])
        secn += 1

    # ---------- Declaration Coverage Matrix & Internal Consistency（可选）----------
    decl = cfg.get('declMatrix') or []
    cons = cfg.get('consistencyTable') or []
    if decl:
        doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        h(doc, '%d. Declaration Coverage　声明覆盖矩阵' % secn, 1)
        rows = []
        for d in decl:
            d = list(d) + ['', ''] * (3 - len(d))
            rows.append([d[0], d[1], d[2]])
        add_table(doc, ['声明项', '状态', '依据 / 原文摘录'], rows, widths=[5.0, 2.2, 9.3])
        secn += 1
    if cons:
        doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        h(doc, '%d. Internal Consistency　一致性核对表' % secn, 1)
        rows = []
        for c in cons:
            c = list(c) + ['', '', ''] * (4 - len(c))
            rows.append([c[0], c[1], c[2], c[3]])
        add_table(doc, ['核对项', '位置 A', '位置 B', '结论'], rows, widths=[3.5, 4.0, 4.0, 2.5])
        secn += 1
    # ---------- Typography / 书写规范（斜体、上下标、特殊字符）----------
    typo = cfg.get('typoTable') or []
    if typo:
        doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        h(doc, '%d. Typographic Conventions　书写规范（斜体 / 上下标 / 特殊字符）' % secn, 1)
        para(doc, '只查跨期刊共通规范（命名法、SI 规定），不查字体、字号、行距等版式项。'
                  'TY1 为确定性结论；其余请作者目视复核。', size=9, italic=True, space_after=6)
        rows = []
        for t in typo:
            t = list(t) + ['', '', '', ''] * (5 - len(t))
            rows.append([t[0], t[1], t[2], t[3], t[4]])
        add_table(doc, ['编号', '位置', '原文 token', '说明', '级别'],
                  rows, widths=[1.3, 2.8, 3.6, 6.8, 1.2])
        secn += 1

    # ---------- Issue Summary ----------
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    h(doc, '%d. Issue Summary　问题汇总（FAIL + WARN）' % secn, 1)
    issues = [it for it in norm if it[1] in ('FAIL', 'WARN')]
    order = {'高': 0, '中': 1, '低': 2}
    issues.sort(key=lambda x: (order.get(x[4], 3), x[0]))
    rows = []
    for i, it in enumerate(issues, 1):
        rows.append([i, it[0], it[2], it[4], it[3]])
    add_table(doc, ['#', 'Category / 类别', 'Issue / 问题', 'Severity / 严重程度', 'Detail / 说明'],
              rows, widths=[1.0, 2.6, 3.8, 1.6, 7.5])
    if not issues:
        para(doc, 'No issues detected. 未发现问题。', size=10)

    # ---------- Chinese comments ----------
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    h(doc, '%d. 自查总结意见' % (secn + 1), 1)
    cn_pairs = [parse_item(x) for x in cfg.get('cnItems', [])]
    cn_mand = [t for t, a in cn_pairs if not a]
    cn_adv = [t for t, a in cn_pairs if a]
    n = 0
    for t in cn_mand:
        n += 1
        _comment(doc, f'{n}. ', t)
    if cn_adv:
        para(doc, '—— 以下为建议修改项 ——',
             size=9.5, italic=True, space_after=6)
        for t in cn_adv:
            n += 1
            _comment(doc, f'{n}. ', t, tag='【建议】')

    # ---------- Citation appropriateness issues (整合自引用恰当性检查 Excel) ----------
    cite_issues = cfg.get('citationIssues') or []
    cite_stats = cfg.get('citationStats') or {}
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    _stem = os.path.splitext(os.path.basename(str(cfg.get('manuscriptFile', ''))))[0]
    _cite_name = cfg.get('citationSource') or (f'{_stem}_引用恰当性检查.xlsx' if _stem else '引用恰当性检查.xlsx')
    h(doc, '%d. 文献引用恰当性检查发现的问题（详见《%s》）' % (secn + 2, _cite_name), 1)
    if cite_stats:
        para(doc, '共核对 %s 条参考文献、%s 处正文引用；其中 %s 处存在疑问或需核实。' % (
            cite_stats.get('refs', '-'), cite_stats.get('citations', '-'),
            cite_stats.get('issues', len(cite_issues))), size=10, space_after=6)
    if cite_issues:
        rows = []
        for it in cite_issues:
            num = it[0] if len(it) > 0 else ''
            cit = it[1] if len(it) > 1 else ''
            verdict = it[2] if len(it) > 2 else ''
            sec = it[3] if len(it) > 3 else ''
            reason = it[4] if len(it) > 4 else ''
            rows.append([num, cit, verdict, sec, reason])
        add_table(doc, ['文献编号', '引用序号', '判断结论', '所属章节', '判断理由 / 建议'],
                  rows, widths=[1.7, 1.7, 3.2, 2.8, 7.1])
    else:
        para(doc, '引用恰当性检查未发现明显问题（若稿件无编号制引用，则本项不适用）。', size=10)
    if cfg.get('citationNote'):
        para(doc, str(cfg['citationNote']), size=9, italic=True, space_after=4)

    # ---------- Limitations / 局限性与需人工核实事项 ----------
    limits = cfg.get('limitations') or []
    if limits:
        doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        h(doc, '%d. 检查局限性与需人工核实事项　Limitations & Items Requiring Manual Verification' % (secn + 3), 1)
        for ln in limits:
            para(doc, '• ' + str(ln), size=10, space_after=4)

    out = cfg['outputPath']
    if not out:
        raise SystemExit('ERROR: 配置缺少 outputPath（报告输出路径）')
    out = os.path.expanduser(out)
    out_dir = os.path.dirname(os.path.abspath(out))
    os.makedirs(out_dir, exist_ok=True)
    doc.save(out)
    print(f'SAVED: {out} | total={total} PASS={counts["PASS"]} FAIL={counts["FAIL"]} '
          f'WARN={counts["WARN"]} N/A={counts["N/A"]} | issues={len(issues)}')


if __name__ == '__main__':
    main()
