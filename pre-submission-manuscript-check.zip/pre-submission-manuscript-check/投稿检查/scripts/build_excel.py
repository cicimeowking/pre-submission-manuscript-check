# -*- coding: utf-8 -*-
"""
根据提取的 JSON + 翻译数据，生成单表 Excel 对照表。
用法:
    python build_excel.py <input.json> <translations.py> <output.xlsx> [--section-map map.json]
    python build_excel.py <input.json> <translations.py> <output.xlsx> [--sections "16-19:引言;21-44:材料与方法;..."]

translations.py 需定义两个字典:
    REF_TITLES_ZH = {1: "题目中译", ...}
    SENT_ZH = {"英文原句": "中文译文", ...}   # 句子需与 JSON 逐字符一致

--sections 语法：段号区间->章节名，用分号分隔，区间用连字符。示例：
  "16-19:引言 Introduction;21-23:材料与方法—数据库搜索;140-149:讨论 Discussion"
输出单表：文献编号|引用序号|文献条目(英文)|题目中文翻译|所属章节|正文原文(英文)|正文中文翻译
"""
import json
import re
import sys
import argparse
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


def load_sections(text):
    """解析 '16-19:名称;21-23:名称' -> {段号: 名称}"""
    mapping = {}
    for seg in text.split(";"):
        seg = seg.strip()
        if not seg:
            continue
        if ":" in seg:
            rng, name = seg.split(":", 1)
        else:
            rng, name = seg, seg
        rng = rng.strip()
        if "-" in rng:
            a, b = rng.split("-", 1)
            for i in range(int(a), int(b) + 1):
                mapping[i] = name.strip()
        else:
            mapping[int(rng)] = name.strip()
    return mapping


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="extract_citations.py 输出的 JSON")
    ap.add_argument("translations", help="翻译数据 py 文件")
    ap.add_argument("output", help="输出 xlsx 路径")
    ap.add_argument("--sections", default="", help="段号区间->章节名映射")
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        DATA = json.load(f)

    # 加载翻译
    ns = {}
    with open(args.translations, "r", encoding="utf-8") as f:
        code = f.read()
    exec(compile(code, args.translations, "exec"), ns)
    REF_TITLES_ZH = ns.get("REF_TITLES_ZH", {})
    SENT_ZH = ns.get("SENT_ZH", {})

    SECTION_OF_PARA = load_sections(args.sections) if args.sections else {}

    wb = Workbook()
    ws = wb.active
    ws.title = "文献引用对照表"
    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
    body_font = Font(name="微软雅黑", size=10)
    thin = Side(style="thin", color="BFBFBF")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    wrap = Alignment(wrap_text=True, vertical="top")
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    headers = ["文献编号", "引用序号", "文献条目（英文原文）", "题目中文翻译",
               "所属章节", "正文原文（英文）", "正文中文翻译"]
    widths = [10, 10, 60, 40, 26, 60, 60]

    ws.cell(row=1, column=1, value="文献引用对照与中译（单表总览）").font = \
        Font(name="微软雅黑", size=13, bold=True, color="1F4E79")
    for ci, h in enumerate(headers, 1):
        c = ws.cell(row=2, column=ci, value=h)
        c.fill = header_fill
        c.font = header_font
        c.alignment = center
        c.border = border
        ws.column_dimensions[get_column_letter(ci)].width = widths[ci - 1]

    missing = []
    row = 3
    for item in DATA:
        n = item["num"]
        ctxs = item["ctxs"]
        ref = item["ref"]
        zh = REF_TITLES_ZH.get(n, "")
        if not ctxs:
            vals = [n, 1, ref, zh, "（正文中未发现显式引用标记）", "", ""]
            for ci, v in enumerate(vals, 1):
                cell = ws.cell(row=row, column=ci, value=v)
                cell.font = body_font
                cell.border = border
                cell.alignment = center if ci in (1, 2) else wrap
            row += 1
            continue
        for ci_idx, c in enumerate(ctxs, 1):
            s = c["sentence"]
            zh_s = SENT_ZH.get(s, "")
            if not zh_s:
                missing.append((n, ci_idx))
            vals = [n, ci_idx, ref, zh, SECTION_OF_PARA.get(c["para"], "正文"),
                    s, zh_s]
            for ci, v in enumerate(vals, 1):
                cell = ws.cell(row=row, column=ci, value=v)
                cell.font = body_font
                cell.border = border
                cell.alignment = center if ci in (1, 2) else wrap
            row += 1

    last = row - 1
    ws.freeze_panes = "A3"
    ws.auto_filter.ref = f"A2:G{last}"
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 24

    wb.save(args.output)
    print("SAVED:", args.output, "| rows:", last - 2)
    print("Missing sentence translations:", missing if missing else "none")


if __name__ == "__main__":
    main()
