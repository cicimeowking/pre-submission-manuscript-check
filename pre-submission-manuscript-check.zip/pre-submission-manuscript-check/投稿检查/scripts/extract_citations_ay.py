# -*- coding: utf-8 -*-
"""
作者-年份制（Author–Year）引用提取与自动匹配。

用法:
    python extract_citations_ay.py <input.docx> <refs.json> --issues <issues.json> \
        [--refs-heading "References"] [--max-refs N]

设计原则（与编号制 extract_citations.py 对齐，输出同一套 refs.json schema）：
    refs.json  : [{"num":1,"label":"Zhang et al., 2020a","ref":"完整条目","ctxs":[{"para":段号,"sentence":"引用句"}]}, ...]

    匹配是**确定性匹配**，不做模糊猜测：
      1. 正文 "Zhang, 2020" -> 只保留列表中姓氏=Zhang 且年份=2020 的条目；
      2. 唯一命中 -> 绑定；
      3. 多篇同姓氏同年份（Zhang 2020a / 2020b）而正文未标 a/b -> 报 "引用标注不完整"，列出候选；
      4. 该姓氏存在但无此年份 -> 报 "年份不符"，列出该姓氏实际年份；
      5. 列表中无此姓氏 -> 报 "查无此文"（多为作者标错或漏列文献）；
      6. 文献列表里从未被正文引用的条目 -> 报 "未被引用"。

issues.json : [{type, label, para, sentence, detail, candidates}, ...]
    type 取值: not_found / year_mismatch / ambiguity / suffix_mismatch / uncited
"""
import argparse
import json
import re
import sys

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

CITE_YEAR = r"((?:19|20)\d{2})([a-z])?"

# 括号内单个引用块：(Zhang et al., 2020a) / (Zhang and Li, 2020) / (Zhang, 2020)
CHUNK_RE = re.compile(
    r"^\s*(?:e\.g\.,?|i\.e\.,?)?\s*"
    r"([A-Z][A-Za-z'’\-]{1,})"
    r"(?:\s+et\s+al\.?)?"
    r"(?:\s*(?:,|and|&)\s*(?:[A-Z][A-Za-z'’\-]{1,}))?"
    r"\s*,?\s*" + CITE_YEAR
)

# 叙述式：Zhang et al. (2020) / Zhang and Li (2020) / Zhang (2020)
NARRATIVE_RE = re.compile(
    r"\b([A-Z][A-Za-z'’\-]{1,})"
    r"(?:\s+et\s+al\.?)?"
    r"(?:\s+(?:and|&)\s+[A-Z][A-Za-z'’\-]{1,})?"
    r"\s*\(" + CITE_YEAR + r"\)"
)

PROTECT = re.compile(
    r"\b(Fig|Figs|e\.g|i\.e|et al|vs|etc|No|al|St|Mt|cf|ca|Suppl)\b\.|(?-i:[B-Z])\.(?=\s+[a-z])",
    re.I,
)


def full_text(elem):
    """递归收集 <w:t> 文本（含超链接/域），跳过 w:del 修订删除内容。"""
    parts = []
    for t in elem.iter('{%s}t' % W_NS):
        anc = t.getparent()
        in_del = False
        while anc is not None:
            if anc.tag == '{%s}del' % W_NS:
                in_del = True
                break
            anc = anc.getparent()
        if in_del:
            continue
        parts.append(t.text or '')
    return ''.join(parts)


def split_sentences(text):
    protected = []

    def repl(m):
        protected.append(m.group(0))
        return f"\x00{len(protected) - 1}\x00"

    t = PROTECT.sub(repl, text)
    out = []
    for p in re.split(r"(?<=[.!?])\s+", t):
        def back(m):
            try:
                return protected[int(m.group(1))]
            except IndexError:
                return ""
        out.append(re.sub(r"\x00(\d+)\x00", back, p))
    return out


def strip_numbering(text):
    """去掉 "[12] " / "12. " / "(12) " 之类前缀编号。"""
    return re.sub(r"^\s*[\[\(]?\d{1,3}[\]\)]?[\.\)]?\s+", "", text).strip()


def parse_entry(text):
    """解析一条参考文献 -> (first_surname, surnames_list, year, suffix)。"""
    t = strip_numbering(text)
    ym = re.search(r"\b((?:19|20)\d{2})([a-z])?\b", t)
    if not ym:
        return "", [], None, ""
    year, suffix = ym.group(1), (ym.group(2) or "")
    head = t[:ym.start()]
    surnames = re.findall(r"[A-Z][A-Za-z'’\-]{1,}", head)
    first = surnames[0] if surnames else ""
    return first, surnames, year, suffix


def extract_body_citations(para_text):
    """从一段正文中提取所有引用 token -> [(surname, year, suffix)]，并保留所在句。"""
    hits = []
    for sent in split_sentences(para_text):
        for pm in re.finditer(r"\(([^()]{2,300})\)", sent):
            inner = pm.group(1)
            # 排除纯数字/纯符号括号（如 (12)、（图 1））
            if not re.search(r"(?:19|20)\d{2}", inner):
                continue
            for chunk in re.split(r"[;；]", inner):
                cm = CHUNK_RE.match(chunk)
                if cm:
                    hits.append((cm.group(1), cm.group(2), cm.group(3) or "", sent))
        for nm in NARRATIVE_RE.finditer(sent):
            hits.append((nm.group(1), nm.group(2), nm.group(3) or "", sent))
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="docx 路径")
    ap.add_argument("output", help="输出 refs.json")
    ap.add_argument("--issues", required=True, help="输出 issues.json（匹配问题清单）")
    ap.add_argument("--refs-heading", default="References")
    ap.add_argument("--max-refs", type=int, default=0)
    args = ap.parse_args()

    from docx import Document
    doc = Document(args.input)
    paras = [full_text(p._p) for p in doc.paragraphs]

    refs_start = None
    for i, t in enumerate(paras):
        if t.strip() == args.refs_heading:
            refs_start = i
            break
    if refs_start is None:
        for i, t in enumerate(paras):
            if t.strip().lower().startswith(args.refs_heading.lower()):
                refs_start = i
                break
    if refs_start is None:
        sys.exit(f"未找到参考文献标题段 '{args.refs_heading}'，请用 --refs-heading 指定")

    body = paras[:refs_start]
    raw_refs = [t.strip() for t in paras[refs_start + 1:] if t.strip()]

    # 解析文献条目（作者-年份制：一段一条；续行并入上一条）
    entries = []
    for line in raw_refs:
        if line.startswith("Table S") or line.startswith("Fig. S") \
           or line.startswith("Disclaimer") or line.startswith("Publisher"):
            break
        first, surnames, year, suffix = parse_entry(line)
        if first and year:
            entries.append({"first": first, "surnames": surnames, "year": year,
                            "suffix": suffix, "text": line})
        elif entries:
            entries[-1]["text"] += " " + line
    if args.max_refs:
        entries = entries[:args.max_refs]

    for idx, e in enumerate(entries, 1):
        e["num"] = idx
        multi = len(e.get("surnames") or []) >= 2
        e["label"] = (f'{e["first"]} et al., {e["year"]}{e["suffix"]}' if multi
                      else f'{e["first"]}, {e["year"]}{e["suffix"]}')

    # 索引：姓氏(小写) -> [entry]
    by_surname = {}
    for e in entries:
        by_surname.setdefault(e["first"].lower(), []).append(e)

    issues = []
    cited_nums = set()
    shadowed = set()  # 存在未消歧引用的姓氏（已报 ambiguity/year_mismatch），避免重复报"未被引用"

    for pi, text in enumerate(body):
        if not text.strip():
            continue
        for surname, year, suffix, sent in extract_body_citations(text):
            key = surname.lower()
            pool = by_surname.get(key, [])
            cite_label = f"{surname}, {year}{suffix}"

            if not pool:
                issues.append({
                    "type": "not_found", "label": cite_label, "para": pi,
                    "sentence": sent.strip(),
                    "detail": f"正文引用 ({cite_label}) 在参考文献列表中找不到姓氏为 {surname} 的条目，"
                              f"可能作者标注有误、年份写错，或该文献未列入参考文献表",
                    "candidates": [],
                })
                continue

            same_year = [e for e in pool if e["year"] == year]
            if not same_year:
                years = sorted({e["year"] for e in pool})
                shadowed.add(key)
                issues.append({
                    "type": "year_mismatch", "label": cite_label, "para": pi,
                    "sentence": sent.strip(),
                    "detail": f"正文引用 ({cite_label}) 的年份在列表中不存在；文献表中 {surname} 的条目年份为 "
                              f"{'、'.join(years)}，请核对正文年份或文献表年份",
                    "candidates": [e["label"] for e in pool],
                })
                continue

            if len(same_year) == 1:
                e = same_year[0]
                if suffix and suffix != e["suffix"]:
                    issues.append({
                        "type": "suffix_mismatch", "label": cite_label, "para": pi,
                        "sentence": sent.strip(),
                        "detail": f"正文写作 ({cite_label})，但文献表中该条为 {e['label']}（后缀不同），请核对",
                        "candidates": [e["label"]],
                    })
                cited_nums.add(e["num"])
                e.setdefault("ctxs", []).append({"para": pi, "sentence": sent.strip()})
                continue

            # 多篇同姓氏同年份：必须靠 a/b 后缀区分
            if suffix:
                exact = [e for e in same_year if e["suffix"] == suffix]
                if len(exact) == 1:
                    e = exact[0]
                    cited_nums.add(e["num"])
                    e.setdefault("ctxs", []).append({"para": pi, "sentence": sent.strip()})
                    continue
                issues.append({
                    "type": "suffix_mismatch", "label": cite_label, "para": pi,
                    "sentence": sent.strip(),
                    "detail": f"正文写作 ({cite_label})，但文献表中同年同作者的条目为 "
                              f"{'、'.join(x['label'] for x in same_year)}，未找到后缀为 {suffix} 的那篇，请核对",
                    "candidates": [e["label"] for e in same_year],
                })
                shadowed.add(key)
                continue

            for e in same_year:
                e.setdefault("ctxs", [])
            shadowed.add(key)
            issues.append({
                "type": "ambiguity", "label": cite_label, "para": pi,
                "sentence": sent.strip(),
                "detail": f"文献表中有 {'、'.join(x['label'] for x in same_year)} 共 {len(same_year)} 篇，"
                          f"但正文只写 ({cite_label})，未标注 a/b 后缀，无法确定指哪一篇，请修改正文标注",
                "candidates": [e["label"] for e in same_year],
            })

    # 反向：从未被正文引用的文献
    for e in entries:
        if e["num"] in cited_nums or e.get("ctxs"):
            continue
        if e["first"].lower() in shadowed:
            issues.append({
                "type": "unclear", "label": e["label"], "para": -1, "sentence": "",
                "detail": f"文献表中有 {e['label']}，但正文该姓氏的引用存在标注问题（年份或 a/b 后缀未对应上），"
                          f"无法判断此条是否被引用；请先修正正文标注后再核对",
                "candidates": [],
            })
        else:
            issues.append({
                "type": "uncited", "label": e["label"], "para": -1,
                "sentence": "",
                "detail": f"文献表中 {e['label']} 在正文中未被引用（按姓氏+年份匹配不到任何引用），"
                          f"请确认是否漏引或应删除该条",
                "candidates": [],
            })

    refs_out = []
    for e in entries:
        ctxs = e.get("ctxs", [])
        refs_out.append({"num": e["num"], "label": e["label"], "ref": e["text"],
                         "year": e["year"], "suffix": e["suffix"], "ctxs": ctxs})

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(refs_out, f, ensure_ascii=False, indent=1)
    with open(args.issues, "w", encoding="utf-8") as f:
        json.dump(issues, f, ensure_ascii=False, indent=1)

    n_ctx = sum(len(r["ctxs"]) for r in refs_out)
    print(f"References heading at para {refs_start}; total refs: {len(refs_out)}; "
          f"matched citations: {n_ctx}; issues: {len(issues)}")
    for it in issues:
        print(f"  [{it['type']}] {it['label']} -> {it['detail'][:70]}")


if __name__ == "__main__":
    main()
