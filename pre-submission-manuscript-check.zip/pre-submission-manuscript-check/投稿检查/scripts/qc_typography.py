# -*- coding: utf-8 -*-
"""书写规范检查（Typographic conventions，TY1–TY7）— 斜体 / 上下标 / 特殊字符。

定位：只查**跨期刊共通的学术书写规范**（基因名斜体、物种拉丁名斜体、统计符号斜体、
化学式与同位素上下标、减号与乘号），不查字体、字号、行距、页边距、色彩等纯版式项。

设计原则（与 SKILL.md 铁律一致）：
  1. 只报差异，不判对错 —— 同一写法在不同位置时斜时正，报"位置 A / 位置 B"；
  2. 需外部词表才能判定的（基因符号 vs 蛋白名），只报"需核实"，不下结论；
  3. 不编造：只输出稿件中真实出现的 token 与段落号。

用法:
    python qc_typography.py <file.docx> [out.json]

输出：stdout 摘要 +（可选）JSON 明细。
"""
import json
import re
import sys

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

# ── 常见拉丁属名（双名法第一个词必须斜体）────────────────────────────
GENERA = {
    "homo", "mus", "rattus", "escherichia", "bacillus", "staphylococcus",
    "streptococcus", "pseudomonas", "salmonella", "saccharomyces", "candida",
    "aspergillus", "penicillium", "drosophila", "caenorhabditis", "danio",
    "xenopus", "gallus", "sus", "bos", "oryza", "arabidopsis", "nicotiana",
    "clostridium", "mycobacterium", "vibrio", "klebsiella", "enterococcus",
    "lactobacillus", "bifidobacterium", "bacteroides", "helicobacter",
    "toxoplasma", "plasmodium", "trypanosoma", "leishmania", "schistosoma",
    "cryptosporidium", "corynebacterium", "listeria", "campylobacter",
    "neisseria", "haemophilus", "borrelia", "treponema", "chlamydia",
    "mycoplasma", "rhodopseudomonas", "thermus", "pyrococcus",
}

# 拉丁属名之外、同样按规范应斜体的分类单元后缀
FAMILY_SUFFIX = ("aceae", "idae", "inae")

# 双名法第二个词若命中以下常见英文词，说明不是种加词，跳过
EPITHET_STOP = {
    "dynamics", "and", "the", "was", "were", "is", "are", "has", "have",
    "with", "from", "that", "this", "than", "into", "both", "also", "such",
    "can", "may", "not", "for", "per", "via", "analysis", "study", "group",
    "patients", "cells", "protein", "proteins", "expression", "levels",
}

# 出现在基因语境但本身不是基因符号的常见缩写，跳过
ACRONYM_WHITELIST = {
    "DNA", "RNA", "MRNA", "CDNA", "PCR", "RT-PCR", "QPCR", "WB", "IHC",
    "ELISA", "FISH", "SNP", "GWAS", "ORF", "UTR", "COI", "AUC", "ROC",
    "SPSS", "KEGG", "GO", "PPI", "ECM", "EMT", "NET", "RNET", "TCA",
    "PLS", "VIP", "FDR", "SD", "IQR", "CI", "CT", "MRI", "PET", "WHO",
}

STAT_PAT = re.compile(r"(?<![A-Za-z])([PpnrtF])\s*(?:[<>=≤≥]|值|value)\s*-?\d*(?:\.\d+)?")
ISO_PAT = re.compile(r"(?<![A-Za-z0-9\[])(\d{2,3}m?)(F|Ga|Cu|Zr|Lu|Y|I|Tc|In|Tl|Ra|Sm)(?![a-z])")
CHEM_PAT = re.compile(r"\b(H2O|CO2|O2|H2SO4|NH3|CaCO3|NaHCO3|H2O2)\b")
CHARGE_PAT = re.compile(r"\b(Ca|Mg|Na|K|Fe|Zn|Cu|Mn)(2\+|\+)")
UNIT_POW = re.compile(r"(?<![A-Za-z])(cm|mm|nm|µm|um|m|L|mL|g|kg)(2|3)(?![0-9])")
POWER10 = re.compile(r"(?<![\d.])10\s*-\s*(\d{1,2})\b")
MULT_X = re.compile(r"\d\s*[xX]\s*\d")
MICRO_U = re.compile(r"\d+\s*(?:u|U)(?:L|g|M|mol)\b")
HYPHEN_MINUS = re.compile(r"(?<![\d\w])-(?=\d+\s*°?C\b)")

# 化学位标：N6-methyllysine、N2,N2-dimethylguanosine 的 6 与 2 按 IUPAC 应作上标
LOCANT_PAT = re.compile(r"(?<![A-Za-z])N(\d+)(?=\s*[,\-–]\s*(?:N|[a-zA-Z]))")

# 基因符号语境（命中后仅报"需核实"，不判对错）
GENE_CTX_A = re.compile(r"\b(?:gene|mRNA|transcript|allele|knockdown|knockout|"
                        r"overexpression|silencing)\s+(?:of\s+)?([A-Z][A-Z0-9]{2,}[0-9]?)\b")
GENE_CTX_B = re.compile(r"\b([A-Z][A-Z0-9]{2,}[0-9]?)\s+(?:gene|mRNA|transcript|expression\b)")

TOKEN_PAT = re.compile(r"[A-Za-z][A-Za-z0-9\-]{2,}")


def _iter_blocks(doc):
    """按文档顺序产出 (段落对象, 是否在表格内)。"""
    body = doc.element.body
    for child in body.iterchildren():
        tag = child.tag.split("}")[-1]
        if tag == "p":
            yield Paragraph(child, doc), False
        elif tag == "tbl":
            tbl = Table(child, doc)
            for row in tbl.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        yield p, True


def _run_italic(run, para):
    """解析 run 的实际斜体状态（run 级 → 字符样式 → 段落样式）。"""
    if run.italic is not None:
        return bool(run.italic)
    try:
        st = run.style
        if st is not None and getattr(st, "font", None) is not None and st.font.italic is not None:
            return bool(st.font.italic)
    except Exception:
        pass
    try:
        st = para.style
        if st is not None and getattr(st, "font", None) is not None and st.font.italic is not None:
            return bool(st.font.italic)
    except Exception:
        pass
    return False


def _para_map(para):
    """返回 (文本, 每字符斜体标记列表, 每字符上标标记, 每字符下标标记)。"""
    text, ital, sup, sub = [], [], [], []
    for r in para.runs:
        t = r.text
        if not t:
            continue
        it = _run_italic(r, para)
        sp = bool(r.font.superscript)
        sb = bool(r.font.subscript)
        text.append(t)
        ital.extend([it] * len(t))
        sup.extend([sp] * len(t))
        sub.extend([sb] * len(t))
    return "".join(text), ital, sup, sub


def _span_flags(flags, m):
    seg = flags[m.start():m.end()]
    return all(seg) if seg else False


def check(doc):
    items = []
    token_seen = {}   # token -> [(para_no, italic)]

    for idx, (para, in_table) in enumerate(_iter_blocks(doc), 1):
        text, ital, sup, sub = _para_map(para)
        if not text.strip():
            continue
        loc = f"第 {idx} 段" + ("（表格内）" if in_table else "")

        # ── T6 整段斜体（>80% 字符斜体且长度 > 60）──
        if len(text) > 60 and ital and sum(ital) / max(1, len(text)) > 0.8:
            items.append(dict(type="TY6", para=idx, loc=loc, token=text[:40],
                              detail="整段几乎全部为斜体（%.0f%%），除特殊文体外通常不应如此" %
                                     (100 * sum(ital) / len(text)), severity="中"))

        # ── T2 物种拉丁双名是否斜体 ──
        for m in re.finditer(r"\b([A-Z][a-z]{2,})(?:\s+|-)([a-z]{3,})\b", text):
            genus = m.group(1).lower()
            epithet = m.group(2).lower()
            if genus not in GENERA or epithet in EPITHET_STOP:
                continue
            if not _span_flags(ital, m):
                items.append(dict(type="TY2", para=idx, loc=loc, token=m.group(0),
                                  detail="物种／属名拉丁文按规范应整体斜体，此处为正体",
                                  severity="中"))
        for m in re.finditer(r"\b([A-Z][a-z]{3,}(?:aceae|idae|inae))\b", text):
            if not _span_flags(ital, m):
                items.append(dict(type="TY2", para=idx, loc=loc, token=m.group(1),
                                  detail="科／亚科级拉丁学名按规范应斜体，此处为正体",
                                  severity="低"))

        # ── T7 基因符号语境（只报需核实）──
        for pat in (GENE_CTX_A, GENE_CTX_B):
            for m in pat.finditer(text):
                tok = m.group(1)
                if tok in ACRONYM_WHITELIST or len(tok) < 3:
                    continue
                s, e = m.start(1), m.end(1)
                if not all(ital[s:e]):
                    items.append(dict(type="TY7", para=idx, loc=loc, token=tok,
                                      detail="出现在基因／mRNA／表达语境中的符号按惯例应斜体（基因符号），"
                                             "此处为正体；若实为蛋白名则保持正体即可", severity="低"))

        # ── T3 统计符号斜体（只报整篇状态与混用，不判该不该斜体）──
        for m in STAT_PAT.finditer(text):
            sym = m.group(1)
            token_seen.setdefault("__STAT__" + sym, []).append((idx, _span_flags(ital, m)))

        # ── T4 上下标 ──
        for m in LOCANT_PAT.finditer(text):
            pos = m.start(1)
            if not all(sup[pos:m.end(1)]):
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(0),
                                  detail="化学位标 %s 按 IUPAC 命名应设为上标（如 N⁶、N²），"
                                         "当前为普通字符" % m.group(1), severity="低"))
        for m in ISO_PAT.finditer(text):
            if not all(sup[m.start():m.start() + len(m.group(1))]):
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(0),
                                  detail="同位素质量数 %s 应设为上标，当前为普通字符" % m.group(1),
                                  severity="低"))
        for m in CHEM_PAT.finditer(text):
            d_start = m.start() + 1
            if not sub[d_start]:
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(1),
                                  detail="化学式中的数字应设为下标，当前为普通字符",
                                  severity="低"))
        for m in CHARGE_PAT.finditer(text):
            tail = m.group(0)[len(m.group(1)):]
            pos = m.start() + len(m.group(1))
            if not all(sup[pos:pos + len(tail)]):
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(0),
                                  detail="离子电荷应设为上标，当前为普通字符", severity="低"))
        for m in UNIT_POW.finditer(text):
            pos = m.start() + len(m.group(1))
            if not sub[pos]:
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(0),
                                  detail="单位指数的数字应设为下标（如 cm³），当前为普通字符",
                                  severity="低"))
        for m in POWER10.finditer(text):
            pos = m.start() + text[m.start():].index(m.group(1))
            if not sup[pos]:
                items.append(dict(type="TY4", para=idx, loc=loc, token=m.group(0),
                                  detail="10 的幂次应设为上标，当前为普通字符", severity="低"))

        # ── T5 特殊字符 ──
        for m in HYPHEN_MINUS.finditer(text):
            items.append(dict(type="TY5", para=idx, loc=loc,
                              token=text[max(0, m.start() - 6):m.end() + 4],
                              detail="温度／负值前的负号用了半角连字符（U+002D），"
                                     "排印规范应为减号（U+2212）", severity="低"))
        for m in MULT_X.finditer(text):
            items.append(dict(type="TY5", para=idx, loc=loc, token=m.group(0),
                              detail="数值相乘用了字母 x，应为乘号 ×", severity="低"))
        for m in MICRO_U.finditer(text):
            items.append(dict(type="TY5", para=idx, loc=loc, token=m.group(0),
                              detail="数量级单位用了字母 u 代替微符号 µ", severity="低"))

        # ── T1 斜体混用：同一 token 有时斜体、有时正体 ──
        for m in TOKEN_PAT.finditer(text):
            tok = m.group(0)
            if tok.isupper() is False and tok[1:].islower() is False:
                pass
            token_seen.setdefault(tok, []).append((idx, _span_flags(ital, m)))

    # ── 汇总 T1 ──
    for tok, occ in token_seen.items():
        if tok.startswith("__STAT__"):
            continue
        flags = {f for _, f in occ}
        if len(occ) >= 2 and len(flags) == 2:
            it_paras = sorted({p for p, f in occ if f})
            rm_paras = sorted({p for p, f in occ if not f})
            items.append(dict(type="TY1", para=it_paras[0], loc="、" * 0 + "多处",
                              token=tok,
                              detail="同一 token 斜体 %d 处（段 %s）／正体 %d 处（段 %s），"
                                     "斜体归属不一致" %
                                     (len(it_paras), ",".join(map(str, it_paras[:6])),
                                      len(rm_paras), ",".join(map(str, rm_paras[:6]))),
                              severity="中"))

    # ── 汇总 T3 统计符号 ──
    for key, occ in token_seen.items():
        if not key.startswith("__STAT__"):
            continue
        sym = key.replace("__STAT__", "")
        flags = {f for _, f in occ}
        if len(flags) == 2:
            items.append(dict(type="TY3", para=occ[0][0], loc="多处", token=sym,
                              detail="统计符号 %s 在全篇 %d 处中斜体与正体混用（斜体 %d 处）"
                                     % (sym, len(occ), sum(1 for _, f in occ if f)),
                              severity="中"))
        elif len(flags) == 1 and False in flags:
            items.append(dict(type="TY3", para=occ[0][0], loc="多处", token=sym,
                              detail="统计符号 %s 全篇 %d 处均为正体；多数期刊要求 P 等统计符号斜体，"
                                     "请按目标刊要求统一" % (sym, len(occ)),
                              severity="低"))

    return items


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    path = sys.argv[1]
    doc = Document(path)
    items = check(doc)

    order = {"TY1": 1, "TY2": 2, "TY7": 3, "TY3": 4, "TY4": 5, "TY5": 6, "TY6": 7}
    items.sort(key=lambda x: (order.get(x["type"], 9), x["para"]))
    NAMES = {
        "TY1": "斜体混用（同一 token 时斜时正）",
        "TY2": "物种／属名／科名拉丁文未斜体",
        "TY7": "基因语境符号未斜体（需核实是否为基因符号）",
        "TY3": "统计符号斜体（P / n / r 等）",
        "TY4": "上下标（化学位标、同位素、化学式、单位指数、10 的幂）",
        "TY5": "特殊字符（负号、乘号、微符号）",
        "TY6": "整段斜体",
    }

    print("=" * 70)
    print("书写规范检查（TY1–TY7）｜只查跨期刊共通规范，不查字体/字号/行距/版式")
    print("=" * 70)
    if not items:
        print("未发现斜体、上下标或特殊字符问题。")
    else:
        from collections import Counter
        c = Counter(x["type"] for x in items)
        for k in sorted(c, key=lambda x: order.get(x, 9)):
            print(f"  {k} {NAMES[k]}：{c[k]} 处")
        print("-" * 70)
        for it in items:
            print(f"[{it['type']}] {it['loc']}｜{it['token']}｜{it['detail']}（{it['severity']}）")

    if len(sys.argv) >= 3:
        with open(sys.argv[2], "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=1)
        print(f"\n明细已写入：{sys.argv[2]}")


if __name__ == "__main__":
    main()
