# -*- coding: utf-8 -*-
"""投稿检查 — 稿件提取脚本（v2）。

一次性提取 .docx 全文 + 结构化辅助信息：
  - 全文（段落含 ##[style] 标题前缀 + 表格 + 内嵌图片尺寸清单）→ 写到 out 文件
  - stdout 结构化摘要：**甲/乙二分类线索初判**、标题页区（题名/作者/单位/通讯作者线索）、
    Author Contributions 原文块、章节序列、摘要/正文字数、图/表/文献数量、
    声明项关键词命中、时间线关键日期

v2.1（2026-11-06）：新增甲/乙二分类线索扫描（医学/生命科学 vs 非医学），
供 Step 0 判定启用「通用流程 G」还是「G + 医学专用流程 M」。

v2（2026-11-06）：新增「标题页作者区」与「Author Contributions 原文块」抽取，
供作者与署名检查（作者全名 / 作者列表 ↔ 贡献一一对应）直接比对；
不再输出"章节是否齐全/顺序是否正确"的倾向性判断（本工具无固定章节模板）。

用法:
    python qc_extract.py <file.docx> <out.txt>

隐私：本脚本只做机械提取与统计；声明项命中≠合格声明，日期先后判定由作者人工确认。
作者姓名与单位仅用于内部自洽性核对，不回显邮箱/电话/ORCID 等联系方式。
"""
import sys
import os
import re
import zipfile

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from docx import Document
from docx.shared import Emu

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'

# ── 章节标题识别模式（小写、去编号后比对）───────────────────────────────
HEADING_PATTERNS = {
    "abstract", "summary", "keywords", "key words",
    "introduction", "background",
    "materials and methods", "material and methods", "methods", "method",
    "patients and methods", "subjects and methods", "methodology",
    "results", "findings",
    "discussion",
    "conclusions", "conclusion",
    "electronic supplementary information", "supplementary information",
    "supplementary materials", "supplementary material",
    "author contributions", "authors' contributions", "author contribution",
    "acknowledgments", "acknowledgements",
    "funding", "funding information",
    "ethical statement", "ethics statement", "ethics approval", "ethical approval",
    "declaration of ethics", "ethics declarations", "ethical considerations",
    "informed consent", "consent for publication", "consent to participate",
    "patient consent",
    "conflict of interest", "conflicts of interest", "competing interests",
    "declaration of competing interest", "declaration of interest",
    "data availability", "data availability statement",
    "availability of data and materials",
    "abbreviations", "references", "reference",
    "patient perspective", "disclosures",
    "use of ai", "ai use", "declaration of generative ai use", "use of generative ai",
}

CN_HEADING_MAP = {
    "摘要": "abstract", "引言": "introduction", "前言": "introduction",
    "材料与方法": "materials and methods", "方法": "methods", "对象与方法": "methods",
    "结果": "results", "讨论": "discussion", "结论": "conclusions",
    "参考文献": "references", "作者贡献": "author contributions",
    "致谢": "acknowledgments", "伦理声明": "ethical statement",
    "利益冲突": "conflict of interest", "数据可用性": "data availability",
    "知情同意": "informed consent",
}

# ── 声明项 → 正则（全文兜底扫描，命中≠合格声明，需回正文确认）───────────
DECL_PATTERNS = [
    ("伦理委员会 / 审批号", r"(ethic\w*\s+committee|IRB\b|institutional\s+review\s+board|IACUC|approval\s*(?:no|number|code|date)|批准号|审批号)"),
    ("知情同意（Informed consent）", r"(informed\s+consent|written\s+consent|consent\s+was\s+obtained|consent\s+for\s+publication|知情同意)"),
    ("试验 / 综述注册号", r"(NCT\d{8}|ChiCTR[\w]*|ISRCTN\d+|ACTRN\d+|UMIN\d+|PROSPERO|CRD\d+|clinicaltrials\.gov|trial\s+registration|注册号)"),
    ("赫尔辛基宣言", r"(Declaration\s+of\s+Helsinki)"),
    ("动物伦理 / 福利规范", r"(ARRIVE|animal\s+welfare|IACUC|Care\s+and\s+Use\s+of\s+Laboratory\s+Animals|GB/T\s*35892|3R\s+principle)"),
    ("数据可用性", r"(data\s+availability|data\s+sharing|available\s+from\s+the\s+corresponding\s+author|数据可用性)"),
    ("利益冲突", r"(conflict\w*\s+of\s+interest|competing\s+interest)"),
    ("资金资助", r"(funding|grant|financial\s+support|supported\s+by|基金|资助)"),
    ("生成式 AI 使用披露", r"(ChatGPT|GPT-4|large\s+language\s+model|generative\s+AI|AI-assisted|AI\s+tool)"),
    ("去标识化 / 隐私保护", r"(de-?identif\w*|anonymi[sz]ed|pseudonymi[sz]ed|patient\s+privacy)"),
]


def full_text(elem):
    """递归收集 elem 内所有 <w:t> 文本（含超链接/域内文字），跳过 w:del 修订删除。"""
    parts = []
    for t in elem.iter('{%s}t' % W_NS):
        anc = t.getparent()
        in_del = False
        while anc is not None:
            if anc.tag == '{%s}del' % W_NS:
                in_del = True
                break
            anc = anc.getparent()
        if in_del:
            continue
        parts.append(t.text or '')
    return ''.join(parts)


def normalize_heading(text):
    """若某行是章节标题，返回归一化名称，否则返回 None。"""
    t = text.strip()
    if not t or len(t) > 90:
        return None
    t = re.sub(r'^##\[[^\]]*\]\s*', '', t).strip()  # 去掉 ##[style] 前缀
    t2 = re.sub(r"^[0-9IVXivx]+(?:\.[0-9]+)*\.?\s+", "", t).strip()
    t2 = t2.rstrip(":. ").strip()
    low = re.sub(r"\s+", " ", t2.lower())
    if low in HEADING_PATTERNS:
        return low
    if t2 in CN_HEADING_MAP:
        return CN_HEADING_MAP[t2]
    low_noparen = re.sub(r"\(.*?\)", "", low).strip()
    if low_noparen in HEADING_PATTERNS:
        return low_noparen
    return None


def word_stats(text):
    """粗略字数：英文按词、中文按字。"""
    return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'\-\.]*", text)) + \
        len(re.findall(r"[\u4e00-\u9fff]", text))


def section_word_counts(text):
    """按章节标题切片，返回有序 dict {章节: 字数}。"""
    buf, order, cur = {}, [], None
    for ln in text.split("\n"):
        h = normalize_heading(ln)
        if h:
            cur = h
            if h not in buf:
                buf[h] = []
                order.append(h)
            continue
        if cur:
            buf[cur].append(ln)
    return {k: word_stats("\n".join(buf[k])) for k in order}


def count_references(text):
    lines = text.split("\n")
    start = None
    for i, ln in enumerate(lines):
        if normalize_heading(ln) in ("references", "reference"):
            start = i
            break
    if start is None:
        return 0, "未找到 References 章节"
    ref_lines = lines[start + 1:]
    nums = set()
    for ln in ref_lines:
        m = re.match(r"^\s*[\[\(]?(\d{1,3})[\]\)\.]\s*", ln)
        if m:
            nums.add(int(m.group(1)))
    if nums:
        return max(nums), "按编号统计"
    cnt = sum(1 for ln in ref_lines
              if re.search(r"\b(19|20)\d{2}\b", ln) and len(ln) > 40)
    return cnt, "按含年份条目估算"


def extract_timeline(text):
    """抓取时间线检查所需的关键日期（T1–T4），供人工判定先后顺序。
    只做机械抽取，不做先后判断。返回 [(标签, 提取片段或 None), ...]"""
    MONTH = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?"
    DATE = (r"(?:\d{1,2}\s+" + MONTH + r"\s+\d{4}"
            r"|" + MONTH + r"\s+\d{1,2},?\s+\d{4}"
            r"|" + MONTH + r"\s+\d{4}"
            r"|\d{4}[-/]\d{1,2}(?:[-/]\d{1,2})?"
            r"|\d{1,2}/\d{1,2}/\d{2,4}"
            r"|\d{4}\s*年\s*\d{1,2}\s*月(?:\s*\d{1,2}\s*日)?)")
    RANGE = DATE + r"\s*(?:to|–|-|—|~|至|到)\s*" + DATE
    GAP_120 = r"(?:(?!\.\s)(?!。)[^\n]){0,120}?"
    GAP_80 = r"(?:(?!\.\s)(?!。)[^\n]){0,80}?"

    probes = [
        ("① 注册日期 / 注册号",
         r"(?:" + DATE + GAP_120 + r"注册|" + r"注册" + GAP_120 + DATE
         + r"|(?:registered|registration|first\s+posted|trial\s+registration)" + GAP_120 + DATE + r")"),
        ("①b 注册号（无日期时仍须记录）",
         r"(?:NCT\d{8}|ChiCTR[\w-]{6,}|ISRCTN\d{8}|ACTRN\d+|UMIN\d+|CRD\d+|"
         r"PROSPERO[\s:]*CRD\d+|ChiCTR-IOR-\d+)"),
        ("② 首例入组 / 招募期（取起点为 D2）",
         r"(?:enrol|recruit|included|admitted|enrolled|招募|入组)" + GAP_120 + RANGE),
        ("②b 研究起止（Study period）",
         r"(?:study\s+(?:period|was\s+conducted)|between|from|研究(?:期间|时间))" + GAP_80
         + DATE + GAP_80 + r"(?:to|and|–|-|至)" + DATE),
        ("③ 伦理批准日期",
         r"(?:approv\w*|ethic\w*|伦理)" + GAP_120 + DATE),
        ("④ 检索日期（系统综述）",
         r"(?:search\w*|检索)" + GAP_120 + DATE),
        ("⑤ 数据截止 / 随访终点",
         r"(?:data\s+cut-?off|last\s+follow-?up|follow-?up\s+(?:ended|until)|"
         r"(?:data|随访)" + GAP_80 + r"截止)" + GAP_80 + DATE),
    ]

    out = []
    for label, pat in probes:
        found, seen = [], set()
        for m in re.finditer(pat, text, re.I):
            snippet = re.sub(r"\s+", " ", m.group(0)).strip()
            key = snippet[:60]
            if key in seen:
                continue
            seen.add(key)
            found.append(snippet[:150])
            if len(found) >= 3:
                break
        if found:
            for s in found:
                out.append((label, s))
        else:
            out.append((label, None))
    return out


# ── 甲/乙二分类线索（只看文首区域，避免参考文献造成误报）───────────────
MED_SIGNALS = [
    ("人类受试者 / 患者", r"\b(patients?|participants?|subjects?|informed\s+consent|enrol\w*|recruit\w*|"
                          r"cohort|case-?control|cross-?sectional|randomi[sz]ed)\b|患者|受试者|受试对象"),
    ("伦理审批", r"\b(ethic\w*\s+committee|IRB\b|institutional\s+review\s+board|IACUC|"
                 r"approval\s*(?:no|number|code)|Declaration\s+of\s+Helsinki)\b|伦理委员会|伦理审批|批准号"),
    ("临床结局 / 诊疗", r"\b(diagnos\w*|therapy|treatment|regimen|dose|dosage|mortality|morbidity|"
                        r"adverse\s+event|efficacy|survival|hospital\w*|surgery)\b|诊断|治疗|剂量|疗效|随访"),
    ("动物实验", r"\b(mice|mouse|rats?|rabbits?|zebrafish|C57BL|BALB/c|Sprague|IACUC|"
                 r"animal\s+(?:care|study|model))\b|动物实验|小鼠|大鼠"),
    ("细胞 / 分子 / 生信", r"\b(cell\s+line|HeLa|HEK293|A549|RNA-?seq|Western\s+blot|qPCR|"
                           r"CRISPR|flow\s+cytometry|GEO|SRA|PDB)\b|细胞系|蛋白表达|基因表达"),
    ("注册号", r"(NCT\d{8}|ChiCTR[\w-]+|ISRCTN\d{8}|ACTRN\d+|UMIN\d+|PROSPERO|CRD\d+)"),
]
NONMED_SIGNALS = [
    ("材料 / 化学 / 工程", r"\b(alloy|catalys\w*|polymer|composite|nanoparticle|coating|"
                          r"tensile|corrosion|sinter\w*|electrode|semiconductor)\b|合金|催化剂|聚合物|涂层"),
    ("计算 / 信息 / 算法", r"\b(neural\s+network|algorithm|benchmark|dataset|compiler|"
                          r"encryption|software\s+architecture|throughput|latency)\b|算法|模型训练|计算框架"),
    ("社科 / 经济 / 管理", r"\b(survey\s+questionnaire|economic\s+model|cost-?effectiveness\s+analysis|"
                          r"policy\s+analysis|organi[sz]ational|interviewees?|Likert)\b|问卷|访谈|政策分析"),
    ("农学 / 环境 / 地学", r"\b(soil|crop|yield\s+per\s+hectare|irrigation|ecosystem|sediment|"
                          r"watershed|fertilizer)\b|土壤|作物|产量|流域"),
]


def classify_signals(text):
    """在文首区域（默认 12000 字符）统计甲/乙类线索，给出机器初判。
    只做线索计数，供人工确认；不做最终判定。"""
    head = text[:12000]
    med, non = [], []
    for label, pat in MED_SIGNALS:
        n = len(re.findall(pat, head, re.I))
        if n:
            med.append((label, n))
    for label, pat in NONMED_SIGNALS:
        n = len(re.findall(pat, head, re.I))
        if n:
            non.append((label, n))

    med_hits = sum(n for _, n in med)
    non_hits = sum(n for _, n in non)
    if med_hits and med_hits >= non_hits:
        verdict = "甲类（医学 / 生命科学）"
        advice = "叠加医学专用流程 M1–M5（伦理深度、T1–T4 时间线、临床一致性、报告指南、生物材料）"
    elif non_hits and non_hits > med_hits:
        verdict = "乙类（非医学）"
        advice = "仅走通用流程 G；医学声明与注册时间线不套用"
    else:
        verdict = "无法判定"
        advice = "两类线索均未命中：按甲类轻量执行，并在报告中注明「类别为推定」"
    return med, non, verdict, advice


def extract_front_matter(doc, max_paras=80):
    """提取标题页区：从文首到首个 Abstract / Introduction 类标题之前。
    用于作者全名、作者列表、单位上标、通讯作者标记的自洽性核对。
    只输出原文行，不做任何"是否合格"的判断。"""
    out, started = [], False
    for para in doc.paragraphs[:max_paras]:
        t = full_text(para._p).strip()
        if not t:
            continue
        h = normalize_heading(t)
        if h in ("abstract", "summary", "introduction", "background"):
            break
        out.append(t)
        started = True
    return out if started else []


def guess_author_lines(front_lines):
    """在标题页区里粗略定位"作者行"（多个姓名用逗号/and/分号分隔的短行）。
    仅作定位线索，作者人数一律以人工核对为准。"""
    hits = []
    for ln in front_lines:
        if len(ln) > 400 or re.search(r"@|https?://|\bdoi\b", ln, re.I):
            continue
        segs = [s.strip() for s in re.split(r",|;|&|\band\b|，|；|、", ln) if s.strip()]
        segs = [s for s in segs if re.search(r"[A-Za-z\u4e00-\u9fa5]", s)]  # 丢掉 "*"、"†" 之类纯符号段
        if len(segs) < 2:
            continue
        name_like = sum(
            1 for s in segs
            if re.fullmatch(r"(?:[A-Z][a-zA-Z'\-]+(?:\s+[A-Z]\.?)?(?:\s+[A-Z][a-zA-Z'\-]+)+"
                            r"|[A-Z]\.(?:\s?[A-Z]\.)*\s+[A-Z][a-zA-Z'\-]+"
                            r"|[\u4e00-\u9fa5]{2,4})[\s\*\u2020\u2021\d,]*", s)
        )
        if name_like >= max(2, len(segs) - 1):
            hits.append((ln, len(segs)))
    return hits[:3]


def extract_author_contributions(text):
    """抓 Author Contributions 段落原文（标题之后 → 下一个 ##[style] 标题或空行分隔的下一节之前）。"""
    lines = text.split("\n")
    keys = ("author contributions", "authors' contributions", "author contribution",
            "authors contributions", "作者贡献", "作者贡献声明")
    start = None
    for i, ln in enumerate(lines):
        h = normalize_heading(ln)
        if h in keys or (start is None and re.match(r"^\s*(author\s+contributions?|authors'?\s+contributions?)",
                                                    re.sub(r"^##\[[^\]]*\]\s*", "", ln), re.I)):
            start = i
            break
    if start is None:
        return []
    buf = []
    for ln in lines[start + 1:]:
        if ln.startswith("##[") and buf:
            break
        if normalize_heading(ln):
            break
        if ln.strip():
            buf.append(ln.strip())
        elif buf:
            break
        if len(buf) > 12:
            break
    return buf


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) < 2:
        print("用法: python qc_extract.py <file.docx> <out.txt>")
        return
    path, out = args[0], args[1]

    doc = Document(path)
    lines, headings = [], []
    table_idx = 0

    # 正文段落（含 ##[style] 标题前缀 + 内嵌图片标记）
    for para in doc.paragraphs:
        t = full_text(para._p)
        style = para.style.name if para.style is not None else ''
        img = ''
        if para._p.findall('.//{http://schemas.openxmlformats.org/drawingml/2006/main}blip'):
            img = ' [IMAGE_IN_PARA]'
        if t.strip() == '' and not img:
            continue
        prefix = ''
        if style.startswith('Heading') or style.startswith('标题'):
            prefix = f'##[{style}] '
        lines.append(prefix + t + img)
        h = normalize_heading(t)
        if h:
            headings.append((h, t.strip()))

    # 表格
    lines.append('\n===== TABLES =====')
    for ti, tbl in enumerate(doc.tables, 1):
        lines.append(f'\n--- TABLE {ti} ---')
        for row in tbl.rows:
            cells = [full_text(c._tc).strip().replace('\n', ' ') for c in row.cells]
            lines.append(' | '.join(cells))
        table_idx += 1

    # 图片尺寸
    lines.append('\n===== IMAGES =====')
    img_count = 0
    z = zipfile.ZipFile(path)
    for n in z.namelist():
        if n.startswith('word/media/'):
            img_count += 1
            info = z.getinfo(n)
            try:
                from PIL import Image
                import io
                im = Image.open(io.BytesIO(z.read(n)))
                w, h = im.size
                lines.append(f'{n} | {w}x{h} px | {info.file_size/1024:.1f} KB')
            except Exception as e:
                lines.append(f'{n} | size {info.file_size/1024:.1f} KB | dim error {e}')

    text = '\n'.join(lines)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(text)

    # ── stdout 结构化摘要 ────────────────────────────────────────────────
    print('=' * 70)
    print(f'提取完成 → {out}')
    print('=' * 70)
    print(f'总字符数: {len(text)}')

    # ── 第一步：甲/乙二分类线索 ─────────────────────────────────────────
    med, non, verdict, advice = classify_signals(text)
    print('\n【第一步 稿件类别线索（机器初判，须人工确认后执行对应流程）】')
    print('  甲类线索（医学 / 生命科学）：')
    if med:
        for label, n in med:
            print(f'    · {label:<22} ×{n}')
    else:
        print('    [未命中]')
    print('  乙类线索（非医学）：')
    if non:
        for label, n in non:
            print(f'    · {label:<22} ×{n}')
    else:
        print('    [未命中]')
    print(f'\n  机器初判: {verdict}')
    print(f'  → {advice}')

    # ── 标题页区（作者与署名核对用）─────────────────────────────────────
    front = extract_front_matter(doc)
    print('\n【标题页区（文首 → Abstract 之前；用于作者全名 / 单位 / 通讯作者核对）】')
    if front:
        for k, ln in enumerate(front, 1):
            print(f'  {k:>2}. {ln[:220]}')
        cand = guess_author_lines(front)
        print('\n  -- 机器识别的候选作者行（人数须人工复核）--')
        if cand:
            for ln, n in cand:
                print(f'    · 约 {n} 个分隔段：{ln[:180]}')
        else:
            print('    [未识别出明显作者行，请直接看上方标题页区原文]')
        star = len(re.findall(r'\*', "\n".join(front)))
        dag = len(re.findall(r'[\u2020\u2021]', "\n".join(front)))
        corr = len(re.findall(r'corresponding\s+author', "\n".join(front), re.I))
        print(f'\n  通讯作者线索：* ×{star} / †‡ ×{dag} / "corresponding author" ×{corr}')
    else:
        print('  [未识别到独立标题页区，作者信息可能写在别处或与摘要连排]')

    # ── Author Contributions 原文块 ────────────────────────────────────
    ac = extract_author_contributions(text)
    print('\n【Author Contributions 原文块（与上方作者列表逐人比对）】')
    if ac:
        for ln in ac:
            print(f'  · {ln[:400]}')
        print('\n  → 核对四点：①人数相同 ②贡献段姓名都能在作者列表找到'
              '\n              ③作者列表每人都有贡献说明 ④叙述顺序与作者顺序一致')
    else:
        print('  [未找到 Author Contributions 段落/标题]')

    print('\n【章节序列（按出现顺序，仅供定位）】')
    for i, (h, orig) in enumerate(headings, 1):
        dup = '  ⚠️ 重复' if any(h2 == h for h2, _ in headings[:i - 1]) else ''
        print(f'  {i:>2}. {h:<40} (原文: {orig}){dup}')

    # 字数
    sec = section_word_counts(text)
    print('\n【字数统计（供人工判断，不自动判定）】')
    print(f'  abstract        {sec.get("abstract", 0)}')
    intro = sec.get('introduction', 0)
    print(f'  introduction    {intro}')
    _decl = {'abstract', 'keywords', 'key words', 'references', 'reference',
             'author contributions', "authors' contributions", 'acknowledgments',
             'acknowledgements', 'funding', 'ethical statement', 'ethics statement',
             'conflict of interest', 'conflicts of interest', 'data availability',
             'data availability statement', 'informed consent', 'abbreviations'}
    body = sum(v for k, v in sec.items() if k not in _decl)
    print(f'  正文字数（约）      {body}')

    # 图/表/文献
    fig_nums = set(re.findall(r'Fig(?:ure)?\.?\s*(\d+)', text, re.I))
    print('\n【图表与文献数量】')
    print(f'  图（Fig 编号去重数）: {len(fig_nums)}')
    print(f'  Word 原生表格数: {table_idx}')
    print(f'  内嵌图片文件数: {img_count}')
    nref, refhow = count_references(text)
    print(f'  参考文献条数: {nref}（{refhow}）')

    # 声明项命中
    print('\n【声明项关键词命中（兜底扫描；命中不等于已构成合格声明，需回正文确认）】')
    for label, pat in DECL_PATTERNS:
        n = len(re.findall(pat, text, re.I))
        print(f'  {label:<30} {"命中 %d 处" % n if n else "[未命中]"}')

    # 时间线
    print('\n【时间线关键日期抽取 ★ 合规红线：请人工比对先后顺序】')
    tl = extract_timeline(text)
    cur = None
    for label, s in tl:
        if label != cur:
            print(f'  {label}')
            cur = label
        if s:
            print(f'      · {s}')
        elif label == cur and s is None and all(x[0] != label or x[1] is None for x in tl if x[0] == label):
            print(f'      · [未检出]')

    print('\n提示：本脚本只做机械提取与统计；作者人数、声明是否合格、日期先后判定由人工确认。')
    print('      本工具不评价章节名称/数量/顺序，也不判断参考文献样式或图片规格。')


if __name__ == '__main__':
    main()
