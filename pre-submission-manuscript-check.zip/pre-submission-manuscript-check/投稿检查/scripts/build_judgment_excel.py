# -*- coding: utf-8 -*-
"""
生成引用恰当性检查表（最终版，保留英文原文两列）。
用法:
    python build_judgment_excel.py --input <refs.json> --translations <translations.py> \
        --judgments <judgments.py> --output <out.xlsx> --sections "16-19:引言;21-44:材料与方法;..."

translations.py 需定义 REF_TITLES_ZH / SENT_ZH（同 build_excel.py）。
judgments.py 需定义 JUDG = {(文献编号, 引用序号): (结论, 判断过程)}，结论取值：
    相关 / 部分相关 / 存疑 / 存疑（疑似编号错误） / 可接受
输出 Excel 两个工作表：
    Sheet1 引用恰当性检查：文献编号|引用序号|文献条目(英文)|题目中文翻译|所属章节|
                          正文原文(英文)|正文中文翻译|相关性判断|判断过程/理由
    Sheet2 问题条目汇总：  文献编号|文献条目(英文)|题目中文翻译|引用序号|所属章节|
                          正文原文(英文)|正文中文翻译|相关性判断|判断过程/理由
    （只列 部分相关/存疑/疑似编号错误/可接受）
    Sheet3 引用匹配问题：   仅当传 --issues 时生成（作者-年份制）：
                          问题类型|文献/引用标识|正文引用原文|位置|说明|候选文献

兼容作者-年份制：refs.json 中每条可带 "label"（如 "Zhang et al., 2020a"），
有 label 时"文献编号"列显示 label，JUDG 的键仍用 num。
"""
import argparse
import json
import os
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter


def load_sections(text):
    mapping = {}
    for seg in text.split(";"):
        seg = seg.strip()
        if not seg:
            continue
        rng, _, name = seg.partition(":")
        rng = rng.strip()
        name = name.strip() if name else rng
        if "-" in rng:
            a, b = rng.split("-", 1)
            for i in range(int(a), int(b) + 1):
                mapping[i] = name
        else:
            mapping[int(rng)] = name
    return mapping


VERDICT_STYLE = {
    "相关": ("C6EFCE", "006100"),
    "部分相关": ("FFEB9C", "9C6500"),
    "存疑": ("FFC7CE", "9C0006"),
    "存疑（疑似编号错误）": ("FFC7CE", "9C0006"),
    "可接受": ("DDEBF7", "1F4E79"),
}
WATCH = ["部分相关", "存疑", "存疑（疑似编号错误）", "可接受"]

HEADER1 = ["文献编号", "引用序号", "文献条目（英文原文）", "题目中文翻译", "所属章节",
           "正文原文（英文）", "正文中文翻译", "相关性判断", "判断过程 / 理由"]
WIDTH1 = [10, 9, 52, 32, 22, 48, 48, 13, 60]
HEADER2 = ["文献编号", "文献条目（英文原文）", "题目中文翻译", "引用序号", "所属章节",
           "正文原文（英文）", "正文中文翻译", "相关性判断", "判断过程 / 理由"]
WIDTH2 = [10, 50, 30, 9, 22, 46, 46, 13, 60]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="extract_citations.py 输出的 JSON")
    ap.add_argument("--translations", required=True, help="翻译数据 py（REF_TITLES_ZH/SENT_ZH）")
    ap.add_argument("--judgments", required=True, help="判断数据 py（JUDG）")
    ap.add_argument("--output", required=True, help="输出 xlsx 路径")
    ap.add_argument("--sections", default="", help="段号区间->章节名映射，分号分隔")
    ap.add_argument("--title", default="", help="Excel 标题（默认自动生成）")
    ap.add_argument("--issues", default="", help="作者-年份制的匹配问题 JSON（extract_citations_ay.py --issues 产物）；"
                                               "提供时额外生成「引用匹配问题」工作表")
    args = ap.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        DATA = json.load(f)

    ns = {}
    for py in (args.translations, args.judgments):
        with open(py, "r", encoding="utf-8") as f:
            exec(compile(f.read(), py, "exec"), ns)
    REF_TITLES_ZH = ns.get("REF_TITLES_ZH", {})
    SENT_ZH = ns.get("SENT_ZH", {})
    JUDG = ns.get("JUDG", {})

    SECTION_OF_PARA = load_sections(args.sections) if args.sections else {}
    title = args.title or "参考文献引用恰当性检查（每条引用逐一核对，含英文原文）"

    wb = Workbook()
    ws = wb.active
    ws.title = "引用恰当性检查"

    def write_header(ws_, headers, widths, color="1F4E79"):
        for ci, (h, w) in enumerate(zip(headers, widths), 1):
            c = ws_.cell(row=2, column=ci, value=h)
            c.fill = PatternFill("solid", fgColor=color)
            c.font = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            c.border = Border(left=Side(style="thin", color="BFBFBF"), right=Side(style="thin", color="BFBFBF"),
                              top=Side(style="thin", color="BFBFBF"), bottom=Side(style="thin", color="BFBFBF"))
            ws_.column_dimensions[get_column_letter(ci)].width = w

    # ---- Sheet1 主表 ----
    ws.cell(row=1, column=1, value=title).font = Font(name="微软雅黑", size=13, bold=True, color="1F4E79")
    write_header(ws, HEADER1, WIDTH1)
    missing_j = []
    missing_s = []
    row = 3
    for item in DATA:
        n = item["num"]
        disp = item.get("label") or n
        ref, zh_title, ctxs = item["ref"], REF_TITLES_ZH.get(n, ""), item["ctxs"]
        for ci_idx, c in enumerate(ctxs, 1):
            verdict, reason = JUDG.get((n, ci_idx), ("未标注", ""))
            if verdict == "未标注":
                missing_j.append((n, ci_idx))
            zh_s = SENT_ZH.get(c["sentence"], "")
            if not zh_s:
                missing_s.append((n, ci_idx))
            fill_color, font_color = VERDICT_STYLE.get(verdict, ("FFFFFF", "000000"))
            vals = [disp, ci_idx, ref, zh_title, SECTION_OF_PARA.get(c["para"], "正文"),
                    c["sentence"], zh_s, verdict, reason]
            for ci, v in enumerate(vals, 1):
                cell = ws.cell(row=row, column=ci, value=v)
                cell.font = Font(name="微软雅黑", size=10, color=font_color)
                cell.alignment = Alignment(horizontal="center" if ci in (1, 2, 8) else "left",
                                           vertical="top", wrap_text=True)
                cell.border = Border(left=Side(style="thin", color="BFBFBF"), right=Side(style="thin", color="BFBFBF"),
                                     top=Side(style="thin", color="BFBFBF"), bottom=Side(style="thin", color="BFBFBF"))
                if ci == 8:
                    cell.fill = PatternFill("solid", fgColor=fill_color)
            row += 1
    last = row - 1
    ws.freeze_panes = "A3"
    ws.auto_filter.ref = f"A2:I{last}"

    # ---- Sheet2 问题条目汇总 ----
    ws2 = wb.create_sheet("问题条目汇总")
    n_watch = sum(1 for it in DATA for ci_idx, c in enumerate(it["ctxs"], 1)
                  if JUDG.get((it["num"], ci_idx), ("", ""))[0] in WATCH)
    ws2.cell(row=1, column=1,
             value=f"需要关注的条目（部分相关 / 存疑 / 疑似编号错误 / 可接受）——共 {n_watch} 条").font = \
        Font(name="微软雅黑", size=13, bold=True, color="C00000")
    write_header(ws2, HEADER2, WIDTH2, color="C00000")
    row2 = 3
    for item in DATA:
        n = item["num"]
        disp = item.get("label") or n
        ref, zh_title = item["ref"], REF_TITLES_ZH.get(n, "")
        for ci_idx, c in enumerate(item["ctxs"], 1):
            verdict, reason = JUDG.get((n, ci_idx), ("未标注", ""))
            if verdict not in WATCH:
                continue
            fill_color, font_color = VERDICT_STYLE.get(verdict, ("FFFFFF", "000000"))
            vals = [disp, ref, zh_title, ci_idx, SECTION_OF_PARA.get(c["para"], "正文"),
                    c["sentence"], SENT_ZH.get(c["sentence"], ""), verdict, reason]
            for ci, v in enumerate(vals, 1):
                cell = ws2.cell(row=row2, column=ci, value=v)
                cell.font = Font(name="微软雅黑", size=10, color=font_color)
                cell.alignment = Alignment(horizontal="center" if ci in (1, 4, 8) else "left",
                                           vertical="top", wrap_text=True)
                cell.border = Border(left=Side(style="thin", color="BFBFBF"), right=Side(style="thin", color="BFBFBF"),
                                     top=Side(style="thin", color="BFBFBF"), bottom=Side(style="thin", color="BFBFBF"))
                if ci == 8:
                    cell.fill = PatternFill("solid", fgColor=fill_color)
            row2 += 1
    last2 = row2 - 1
    ws2.freeze_panes = "A3"
    ws2.auto_filter.ref = f"A2:I{last2}"

    # ---- Sheet3 引用匹配问题（作者-年份制专用）----
    n_issue = 0
    if args.issues and os.path.isfile(args.issues):
        with open(args.issues, "r", encoding="utf-8") as f:
            ISSUES = json.load(f)
        TYPE_ZH = {
            "not_found": "正文引用查无此文",
            "year_mismatch": "年份不符",
            "ambiguity": "正文标注不完整（缺 a/b）",
            "suffix_mismatch": "后缀不符",
            "uncited": "文献未在正文引用",
            "unclear": "无法判断（需先修正）",
        }
        ws3 = wb.create_sheet("引用匹配问题")
        ws3.cell(row=1, column=1,
                 value=f"正文引用与文献列表匹配问题（作者-年份制）——共 {len(ISSUES)} 条").font = \
            Font(name="微软雅黑", size=13, bold=True, color="9C0006")
        HEADER3 = ["问题类型", "文献 / 引用标识", "正文引用原文", "位置", "说明", "候选文献"]
        WIDTH3 = [24, 24, 58, 10, 72, 40]
        write_header(ws3, HEADER3, WIDTH3, color="9C0006")
        r3 = 3
        for it in ISSUES:
            para = it.get("para", -1)
            loc = "文献表" if para is None or para < 0 else f'第 {para} 段'
            vals = [TYPE_ZH.get(it.get("type"), it.get("type")),
                    it.get("label", ""), it.get("sentence", ""), loc,
                    it.get("detail", ""), "、".join(it.get("candidates") or [])]
            for ci, v in enumerate(vals, 1):
                cell = ws3.cell(row=r3, column=ci, value=v)
                cell.font = Font(name="微软雅黑", size=10, color="000000")
                cell.alignment = Alignment(horizontal="center" if ci == 4 else "left",
                                           vertical="top", wrap_text=True)
                cell.border = Border(left=Side(style="thin", color="BFBFBF"), right=Side(style="thin", color="BFBFBF"),
                                     top=Side(style="thin", color="BFBFBF"), bottom=Side(style="thin", color="BFBFBF"))
                if ci == 1:
                    cell.fill = PatternFill("solid", fgColor="FFC7CE")
            r3 += 1
        ws3.freeze_panes = "A3"
        ws3.auto_filter.ref = f"A2:F{r3 - 1}"
        n_issue = len(ISSUES)

    wb.save(args.output)
    print("SAVED:", args.output, "| main rows:", last - 2, "| watch rows:", last2 - 2,
          "| match issues:", n_issue)
    if missing_j:
        print("MISSING JUDGMENTS:", missing_j)
    if missing_s:
        print("MISSING TRANSLATIONS:", missing_s)


if __name__ == "__main__":
    main()
